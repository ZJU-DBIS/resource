/*Header file for octree */
/* Bao Nguyen */
/* Reference code for octree from Gerris Flow Solver */
/* http://gfs.sourceforge.net/wiki/index.php/Main_Page */

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <glib.h>
//#include <gts.h>

#if FTT_2D
# define FTT_CELLS     4
#else  /* FTT_3D */
# define FTT_CELLS     8
#endif /* FTT_3D */


typedef struct _FttOct     FttOct;
typedef struct _FttCell FttCell; //cell
typedef struct _FttCellChildren FttCellChildren; //children of a cell
typedef struct _FttCellNeighbors FttCellNeighbors; //neighbors of a cell

typedef struct _FttVector FttVector; //position of a cell [in middle w/ 3D cordinates]

typedef enum
{
  FTT_PRE_ORDER,
  FTT_POST_ORDER
} FttTraverseType;

typedef enum
{
  FTT_RIGHT = 0,
  FTT_LEFT,
  FTT_TOP,
  FTT_BOTTOM,
#if (!FTT_2D)
  FTT_FRONT,
  FTT_BACK,
#endif /* FTT_3D */
  FTT_NEIGHBORS
} FttDirection;


typedef enum
{
  FTT_TRAVERSE_LEAFS          = 1 << 0,
  FTT_TRAVERSE_NON_LEAFS      = 1 << 1,
  FTT_TRAVERSE_LEVEL          = 1 << 2,
  FTT_TRAVERSE_BOUNDARY_FACES = 1 << 3,
  FTT_TRAVERSE_DESTROYED      = 1 << 4,
  FTT_TRAVERSE_ALL            = FTT_TRAVERSE_LEAFS | FTT_TRAVERSE_NON_LEAFS
} FttTraverseFlags;


typedef void      (* FttCellTraverseFunc)            (FttCell * cell,
						      gpointer data);
typedef void      (* FttCellInitFunc)                (FttCell * cell,
						      gpointer data);

typedef void      (* FttCellCleanupFunc)             (FttCell * cell,
						      gpointer data);

typedef gboolean  (* FttCellRefineFunc)              (FttCell * cell,
						      gpointer data);

typedef gboolean  (* FttCellCoarsenFunc)        (FttCell * cell,
						 gpointer data);


typedef enum
{
  FTT_X = 0,
  FTT_Y,
#if (!FTT_2D)
  FTT_Z,
#endif /* FTT_3D */
  FTT_DIMENSION,
  FTT_XY,
#if FTT_2D
  FTT_XYZ = FTT_XY
#else  /* FTT_3D */
  FTT_XYZ
#endif /* FTT_3D */
} FttComponent;

#define FTT_NEIGHBORS_2D (FTT_BOTTOM + 1)
#define FTT_CELLS_DIRECTION(d) (FTT_CELLS/2)

#define  FTT_CELL_ID(c)           ((c)->flags & FTT_FLAG_ID)

#define  FTT_CELL_IS_LEAF(c)      ((c)->children == NULL)
#define  FTT_CELL_IS_ROOT(c)      ((c)->parent == NULL)
#define  FTT_ROOT_CELL(c)         ((struct _FttRootCell *) c)
#define  FTT_CELL_IS_DESTROYED(c) (((c)->flags & FTT_FLAG_DESTROYED) != 0)

#define              ftt_cell_parent(c) ((c)->parent ?\
                                         (c)->parent->parent : NULL)

/*GTS_C_VAR*/ gint ftt_opposite_direction[FTT_NEIGHBORS];
#define FTT_OPPOSITE_DIRECTION(d)     (ftt_opposite_direction[d])

//determine the cell level, so that we can calculate the size
#define              ftt_cell_level(c)  ((c)->parent ?\
                                         (c)->parent->level + 1 :\
                                   ((struct _FttRootCell *) c)->level)

typedef enum {
  FTT_FLAG_ID        = 7,
  FTT_FLAG_DESTROYED = 1 << 3,
  FTT_FLAG_LEAF      = 1 << 4,        /* used only for I/O operations */
  FTT_FLAG_TRAVERSED = FTT_FLAG_LEAF, /* used for face traversal */
  FTT_FLAG_USER      =      5         /* user flags start here */
} FttCellFlags;




/**
 * ftt_cell_children_direction:
 * @cell: a #FttCell.
 * @d: a direction.
 * @children: a #FttCellChildren.
 *
 * Fills @children with the children (2 in 2D, 4 in 3D)
 * of @cell in direction @d.
 * 
 * This function fails if @cell is a leaf.
 *
 * Returns: the number of children in direction @d.
 */



/* Position of cell */
struct _FttVector{
	gdouble x, y, z;
};

struct _FttCellNeighbors{
	FttCell *c [FTT_NEIGHBORS];
};

struct _FttCellChildren{
	FttCell * c[FTT_CELLS];
};

struct _FttCell{
	guint flags; 
	guint nvramflag;
	guint deleted;
	gpointer data; 
	struct _FttOct * parent, *children, * newparent;
};

struct _FttRootCell{
	FttCell cell;
	FttCellNeighbors neighbors;
	FttVector pos; 
	guint level;
	gpointer parent; 
};


struct _FttOct{
	guint level; //depth of octree
	FttCell * parent;
	FttCellNeighbors neighbors;
	FttVector pos ;
	FttCell cell[FTT_CELLS];
};

static inline guint ftt_cell_children_direction (const FttCell * cell,
				   FttDirection d,
				   FttCellChildren * children);


/**
 * @cell: a FttCell
 * @neighbors: type FttCellNeighbors which is array of FttCell
**/

static inline void ftt_cell_neighbors (const FttCell * cell,
			 FttCellNeighbors * neighbors);

/**
 * @parent: a fttcell 
 * @check_neighbors : boolean 
 * @init: a #FttCellInitFunc or Null
 * @data: user data pass to a init to add to cell
 * Create octree
**/
static void oct_new(FttCell *parent, 
	     gboolean check_neighbors,
             FttCellInitFunc init,
	     gpointer data, guint nvram);

/**
 * ftt_cell_refine:
 * @root: a #FttCell.
 * @refine: a #FttCellRefineFunc.
 * @refine_data: user data to pass to @refine.
 * @init: a #FttCellInitFunc or %NULL.
 * @init_data: user data to pass to @init.
 *
 * Recursively refines the tree starting from @root. Each leaf of the
 * tree is tested for refinement using the @refine function. The new
 * refined cells created are initialized using @init (if not %NULL)
 * and are themselves recursively refined.  
 */

void ftt_cell_refine(FttCell * root,
                     FttCellRefineFunc refine,
                     gpointer refine_data,
                     FttCellInitFunc init,
                     gpointer init_data);


/*
 * oct_destroy: destroy octree
 * @oct: octree to destroy
 * @cleanup: clean up funtion or null
 * @data: data of cell destroy
*/
static void oct_destroy (FttOct * oct,
			 FttCellCleanupFunc cleanup,
			 gpointer data);

/**
 * ftt_cell_destroy:
 * @cell: a #FttCell.
 * @cleanup: a #FttCellCleanupFunc to call before destroying @cell or %NULL.
 * @data: user data to pass to @cleanup.
 * Frees all memory allocated for @cell and its descendants.
 *
 * The user-defined function @cleanup is called prior to freeing memory.
 */
void ftt_cell_destroy(FttCell *cell,
		      FttCellCleanupFunc cleanup,
	              gpointer data);


/**
 * ftt_cell_traverse:
 * @root: the root #FttCell of the tree to traverse.
 * @order: the order in which the cells are visited - %FTT_PRE_ORDER,
 * %FTT_POST_ORDER. 
 * @flags: which types of children are to be visited.
 * @max_depth: the maximum depth of the traversal. Cells below this
 * depth will not be traversed. If @max_depth is -1 all cells in the
 * tree are visited.
 * @func: the function to call for each visited #FttCell.
 * @data: user data to pass to @func.
 *
 * Traverses a cell tree starting at the given root #FttCell. Calls
 * the given function for each cell visited.  
 */
void ftt_cell_traverse(FttCell * root, 
	               FttTraverseType order,
		       FttTraverseFlags flags,
                       gint max_depth,
	               FttCellTraverseFunc func,
	               gpointer data);

/**
 * print_oct_tree:
 * @root: the root #Fttcell of the tree to print.
 *
 * Print a cell tree starting from the root cell of a box.
 */
void print_oct_tree(FttCell * root, FttTraverseType order);

/**
 * ftt_cell_new:
 * @init: a #FttCellInitFunc or %NULL.
 * @data: user data to pass to @init.
 *
 * Returns: a new root #FttCell, initialized by calling @init (if not %NULL).
 */
//initialize 1st cell
FttCell * ftt_cell_new (FttCellInitFunc init,
			gpointer data);

/*
 * print_oct_tree to print the tree
 * @root : the root cell of octree
 * @order : type of traverse pre order or post order
*/
void print_oct_tree(FttCell * root, FttTraverseType order);

/*
 * print_pre_order: print tree pre_order
 * @root: Ftt cell
 */
void print_pre_ordrer(FttCell * root);

/*
 * print_post_order: print tree pre_order
 * @root: Ftt cell
 */
void print_post_ordrer(FttCell * root);


/*
 * ftt_cell_refine_single: refine just one cell
 * @cell : Ftt cell
 * @int : init function or NULL
 * @init_data: initial data send to refine the cell
*/
void ftt_cell_refine_single (FttCell * cell,
			     FttCellInitFunc init,
			     gpointer init_data, guint nvram);

//traverse leaf
static void cell_traverse_leafs (FttCell * cell,
				 gint max_depth,
				 FttCellTraverseFunc func,
				 gpointer data);

//traverse nonleaf cell
static void cell_traverse_pre_order_nonleafs (FttCell * cell,
					      gint max_depth,
					      FttCellTraverseFunc func,
					      gpointer data);

//traverse nonleafs cells
static void cell_traverse_post_order_nonleafs (FttCell * cell,
					       gint max_depth,
					       FttCellTraverseFunc func,
					       gpointer data);

//traverse certain level
static void cell_traverse_level (FttCell * cell,
				 gint max_depth,
				 FttCellTraverseFunc func,
				 gpointer data);

//traverse certain level
static void cell_traverse_level_leafs (FttCell * cell,
				       gint max_depth,
				       FttCellTraverseFunc func,
				       gpointer data);

static void cell_traverse_level_non_leafs (FttCell * cell,
					   gint max_depth,
					   FttCellTraverseFunc func,
					   gpointer data);

//traverse preorder all
static void cell_traverse_pre_order_all (FttCell * cell,
					 gint max_depth,
					 FttCellTraverseFunc func,
					 gpointer data);

//traverse post order all 
static void cell_traverse_post_order_all (FttCell * cell,
					  gint max_depth,
					  FttCellTraverseFunc func,
					  gpointer data);

//traverse function
void ftt_cell_traverse (FttCell * root,
			FttTraverseType order,
			FttTraverseFlags flags,
			gint max_depth,
			FttCellTraverseFunc func,
			gpointer data);

//calculate size associated with level of a cell
static gdouble ftt_level_size (guint level);

//determine the size of the cell
static gdouble ftt_cell_size (const FttCell * cell);

//upadate level of children octree at a cell
static void update_children_level (FttCell * parent);

//set level
void ftt_cell_set_level (FttCell * root, guint level);

//set position of a cell
void ftt_cell_pos (const FttCell * cell, FttVector * pos);

//return neighbor of a cell
static inline FttCell * ftt_cell_neighbor_not_cached (const FttCell * cell,
					FttDirection d);

//determine neighboors of cell
static  inline void ftt_cell_neighbors_not_cached (const FttCell * cell,
				    FttCellNeighbors * neighbors);

//return neighbor of a cell in specific direction
static inline FttCell * ftt_cell_neighbor (const FttCell * cell,
			     FttDirection d);

/* helper function to create neighbors of a cell */
static inline void ftt_cell_neighbors (const FttCell * cell,
			 FttCellNeighbors * neighbors);

//refine func
static gboolean refineFunc (FttCell * cell, gpointer refine);

//initialize 1st cell
FttCell * ftt_cell_new (FttCellInitFunc init,
			gpointer data);

//traverse funt - user defined
void traverseFunc(FttCell * cell, gpointer data);

//init function [need another good define by user]
void addFunc(FttCell * cell, gpointer data);

//traverse funt - user defined
void traverseFunc(FttCell * cell, gpointer data);

//predicate for refine
int refine_pred(FttCell* cell, int theta);

//if cell is inside mesh
gboolean inside_mesh(FttCell* cell, int theta);
gboolean inside_mesh1(FttCell* cell, int theta);
//if point is inside mesh
gboolean point_inside_mesh(double point[3], double * mesh);
//for another mesh
gboolean point_inside_mesh1(double point[3], double * mesh);
//get mesh infor
double * get_mesh(double theta);
//z - coordinate condition
gboolean z_inside(double z);
//predicate for location refine
int refine_pred1(FttCell* cell, int theta);


static gboolean refineLocationFunc (FttCell * cell, gpointer refine);
//coarsen check
gboolean ftt_cell_coarsen           (FttCell * root,
						 FttCellCoarsenFunc coarsen,
						 gpointer coarsen_data,
						 FttCellCleanupFunc cleanup,
						 gpointer cleanup_data);
//refine octree [init data for children]
static void oct_new_refine (FttCell * parent,
		     gboolean check_neighbors,
		     FttCellInitFunc init,
		     gpointer data, guint nvram);

//pm_octree_insert function

void ftt_cell_insert_pm(FttCell * v0, FttCellInitFunc init, gpointer init_data, FttCell * v1, gboolean checkneighbor, guint nvram);
//update
void ftt_cell_update_pm(FttCell * v0, FttCellInitFunc init, gpointer init_data, FttCell * v1, guint nvram);
//refine corner
void ftt_refine_corner (FttCell * cell, FttCellInitFunc init, gpointer init_data);
//pm_octree refine function
void ftt_cell_refine_pm (FttCell * root,
		      FttCellRefineFunc refine,
		      gpointer refine_data,
		      FttCellInitFunc init,
		      gpointer init_data,
			  FttCell * pmroot, guint nvmram, FttCell * mainroot);
//output nodes and elements
void tree2file(FttCell * rootcell);

//extract each octant in mesh to output txt file 
void print_octan_points(FttCell * root);

//partition tree to 2 parts: 1 in dram and 1 in nvram
void pm_partition(FttCell * root, guint part);

//merge 2 trees in dram and nvram into 1 tree in nvram
void pm_merge(FttCell * root, guint part);

//merge just a part of tree in Dram in to nvram
void pm_partial_merge(FttCell * root, guint part);

void pm_refine_location_test(FttCell * rootcell, FttCell * pmrootcell, guint i);
//test case
//void pm_persistent_test(FttCell * v0, FttCell * v1);
void pm_gabage(FttCell * rootcell);

//refine function to refine cell in pmoctree for value base
void ftt_cell_refine_value_pm (FttCell * v0,
	FttCellRefineFunc refine,
	gpointer refine_data,
	FttCellInitFunc init,
	gpointer init_data,
  	FttCell * v1, guint nvram, FttCell * mainroot);

//balance  tree
void pm_balance(FttCell * root, FttCellInitFunc init, gpointer init_data);

/* predicate define a octant should be modified or not  for value base*/
int refine_value_pred(FttCell* cell, int value);
//user define -> under what condtion the cell will be refine (now it set to certain level e.g octant value
static gboolean refineValueFunc (FttCell * cell, gpointer refine);
static gboolean refineLocationFunc1 (FttCell * cell, gpointer refine);
//test case 2
int refine_pred1(FttCell* cell, int theta);
gboolean z_inside1(double z);

//naive garbage collector 
void garbage_collector(FttCell * root);

//print tree
void print_octan_points(FttCell * root);
void print_pre_order(FttCell * root);
void print_post_order(FttCell * root);
void print_test(FttCell * rootcell, FttCell * pmrootcell);
//remark the flag, the tree on dram now save to nvram
void save_nvram(FttCell * root);

