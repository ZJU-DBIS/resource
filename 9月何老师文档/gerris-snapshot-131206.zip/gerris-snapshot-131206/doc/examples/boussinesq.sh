python -u test.py boussinesq
