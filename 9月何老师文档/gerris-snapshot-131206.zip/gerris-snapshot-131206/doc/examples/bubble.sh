python -u test.py bubble
