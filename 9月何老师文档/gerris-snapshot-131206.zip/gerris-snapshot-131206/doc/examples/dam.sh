python -u test.py dam
