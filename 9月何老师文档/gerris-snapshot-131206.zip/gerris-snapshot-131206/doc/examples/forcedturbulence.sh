python -u test.py forcedturbulence
