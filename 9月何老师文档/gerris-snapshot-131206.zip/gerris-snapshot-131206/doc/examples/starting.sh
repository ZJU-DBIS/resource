python -u test.py starting
