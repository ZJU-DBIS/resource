python -u test.py tides
