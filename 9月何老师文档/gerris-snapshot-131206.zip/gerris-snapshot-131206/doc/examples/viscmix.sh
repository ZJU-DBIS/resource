python -u test.py viscmix
