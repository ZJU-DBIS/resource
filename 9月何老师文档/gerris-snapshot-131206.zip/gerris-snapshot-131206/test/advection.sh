python -u test.py advection
