python -u test.py annulus
