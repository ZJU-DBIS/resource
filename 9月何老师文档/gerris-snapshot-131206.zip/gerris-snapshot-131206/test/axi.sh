python -u test.py axi
