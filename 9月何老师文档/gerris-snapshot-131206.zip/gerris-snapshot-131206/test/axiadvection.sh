python -u test.py axiadvection
