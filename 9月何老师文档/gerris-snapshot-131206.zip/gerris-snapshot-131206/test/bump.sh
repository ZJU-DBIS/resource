python -u test.py bump
