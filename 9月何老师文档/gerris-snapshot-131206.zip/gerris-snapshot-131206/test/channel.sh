python -u test.py channel
