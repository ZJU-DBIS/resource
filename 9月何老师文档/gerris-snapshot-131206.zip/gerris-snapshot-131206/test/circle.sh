python -u test.py circle
