python -u test.py conservation
