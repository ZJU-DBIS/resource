python -u test.py cosine
