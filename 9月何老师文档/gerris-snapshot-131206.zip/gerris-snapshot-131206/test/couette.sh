python -u test.py couette
