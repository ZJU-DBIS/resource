python -u test.py cylinder
