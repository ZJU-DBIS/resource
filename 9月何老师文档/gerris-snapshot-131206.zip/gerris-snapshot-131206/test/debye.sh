python -u test.py debye
