python -u test.py diffusion
