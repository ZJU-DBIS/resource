python -u test.py dumbell
