python -u test.py electro
