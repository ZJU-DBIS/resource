python -u test.py gaussian
