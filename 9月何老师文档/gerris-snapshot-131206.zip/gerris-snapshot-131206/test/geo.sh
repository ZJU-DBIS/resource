python -u test.py geo
