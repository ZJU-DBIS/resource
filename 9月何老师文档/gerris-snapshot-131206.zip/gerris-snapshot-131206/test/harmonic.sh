python -u test.py harmonic
