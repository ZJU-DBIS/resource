python -u test.py height
