python -u test.py hexagon
