python -u test.py hydrostatic
