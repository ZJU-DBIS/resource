python -u test.py kinetic
