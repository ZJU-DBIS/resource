python -u test.py lake
