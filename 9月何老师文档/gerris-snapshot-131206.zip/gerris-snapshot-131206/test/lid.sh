python -u test.py lid
