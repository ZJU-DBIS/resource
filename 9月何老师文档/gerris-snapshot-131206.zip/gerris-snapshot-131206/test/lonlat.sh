python -u test.py lonlat
