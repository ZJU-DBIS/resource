python -u test.py merging
