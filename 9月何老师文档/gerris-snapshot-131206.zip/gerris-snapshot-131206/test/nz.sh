python -u test.py nz
