python -u test.py oscillation
