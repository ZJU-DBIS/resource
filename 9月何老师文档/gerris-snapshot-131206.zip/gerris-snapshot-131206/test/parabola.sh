python -u test.py parabola
