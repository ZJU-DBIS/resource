python -u test.py periodic
