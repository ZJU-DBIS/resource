python -u test.py planar
