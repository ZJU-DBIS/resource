python -u test.py plate
