python -u test.py plateau
