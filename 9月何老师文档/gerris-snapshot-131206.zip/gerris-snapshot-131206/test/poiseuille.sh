python -u test.py poiseuille
