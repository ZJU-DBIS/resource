python -u test.py poisson
