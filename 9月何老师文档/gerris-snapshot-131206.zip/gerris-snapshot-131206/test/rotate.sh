python -u test.py rotate
