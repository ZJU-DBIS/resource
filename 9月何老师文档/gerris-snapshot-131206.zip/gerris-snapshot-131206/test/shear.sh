python -u test.py shear
