python -u test.py shock
