python -u test.py shore
