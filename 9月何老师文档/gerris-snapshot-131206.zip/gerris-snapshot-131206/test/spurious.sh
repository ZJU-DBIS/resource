python -u test.py spurious
