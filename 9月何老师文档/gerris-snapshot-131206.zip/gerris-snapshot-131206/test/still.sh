python -u test.py still
