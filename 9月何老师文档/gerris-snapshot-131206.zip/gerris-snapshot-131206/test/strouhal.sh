python -u test.py strouhal
