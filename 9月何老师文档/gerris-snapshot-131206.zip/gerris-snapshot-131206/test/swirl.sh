python -u test.py swirl
