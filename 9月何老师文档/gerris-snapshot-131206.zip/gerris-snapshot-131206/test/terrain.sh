python -u test.py terrain
