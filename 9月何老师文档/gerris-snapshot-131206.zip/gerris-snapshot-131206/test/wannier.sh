python -u test.py wannier
