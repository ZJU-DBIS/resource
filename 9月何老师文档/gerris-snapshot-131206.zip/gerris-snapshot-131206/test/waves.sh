python -u test.py waves
