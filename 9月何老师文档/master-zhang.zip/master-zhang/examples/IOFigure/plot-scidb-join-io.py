#!/usr/bin/python

import numpy as np
import matplotlib as PlotLib
PlotLib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import os

PlotLib.rcParams.update({'font.size': 16})
PlotLib.rcParams['xtick.major.pad'] = '8'
PlotLib.rcParams['ytick.major.pad'] = '8'

f1 = open('IOReadBalance.txt', 'r')
lines = f1.readlines()
f1.close()

x0 = []
x1 = []

for line in lines:
	p = line.split()

	x0.append(float(p[1]))
	x1.append(float(p[3]))

fig = plt.figure()
graph1 = fig.add_subplot(111)

plt.title('IO Read Balance a Tree')

pdf = PdfPages( "IORBalance.pdf" )

graph1.set_xlabel("Arrival Time (sec)")
graph1.set_ylabel("File Offset ")
#graph1.set_xlim([0,400])
#graph1.set_ylim([3e8,5.5e8])
#graph2.set_ylabel("Heap Size Inc/Dec (KB)")

xv0 = np.array(x0)
xv1 = np.array(x1)

#print np.average(x1)
#print np.average(x3)

line1 = graph1.plot(xv1, xv0, markersize = 5, marker='.',linestyle='--', label='IO')


#graph1.legend(loc="upper left", ncol=0)
#graph1.legend(loc=0)
#graph1.legend(bbox_to_anchor=(0.4,0.75), loc=0, ncol=2)
#graph2.legend(loc="upper right")
#plt.show()

pdf.savefig(fig, bbox_inches='tight' )
pdf.close()
