#include <stdio.h>
#include <stdlib.h>
#include "etree.h"
#include "schemax.h"

#define LEN 1024

/* Check balancing of the tree */
int checkBalancing(etree_t *ep, etree_addr_t root){

	int octlevel = root.level;
	int result; //find neighbor result
	int nlevel; //neigbor level
    int dir;  //direction
	
	 for(dir = 8; dir < 14; dir++){
		 etree_addr_t * naddr;
		 naddr = malloc(sizeof(etree_addr_t));
		 result = etree_findneighbor(ep, root, dir, naddr, NULL, NULL); 
		if(result == 0){
			nlevel = naddr->level;
			if((nlevel - octlevel) > 1 || (octlevel - nlevel) > 1){

	printf("Level of octant = %d and level of octan's neighbor  = %d  in direction %d \n", octlevel, nlevel, dir);

 	printf("Octant: addr.x=%d, addr.y=%d, addr.z=%d, level=%d, type=%d\n", root.x, root.y, root.z, root.level, root.type);
	printf("Neighbor: addr.x=%d, addr.y=%d, addr.z=%d, level=%d, type=%d\n", naddr->x, naddr->y, naddr->z, naddr->level, naddr->type);

				return 1;
				free(naddr);
			}
		}
 		free(naddr);
	}
	return 0;

}


/* 
 * traverse - Walk the tree in z-order (pre-order)
 */
/* $begin traverse */
int traverse(etree_t *ep)
{
    etree_addr_t addr;
    void* payload;
    int count;
   // char buf[ETREE_MAXBUF];
    etree_error_t err;
    const char* field_desc = NULL;
    char* schema;
    schema = etree_getschema(ep);

    if (schema != NULL) {
	field_desc = "*";
	free (schema);
    }

    /* Get the initial cursor */
    addr.x = addr.y = addr.z = addr.t = addr.level = 0;
    if (etree_initcursor(ep, addr) != 0) {
        fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));
        exit(-1);
    }

    payload = malloc (etree_getpayloadsize(ep));

    /* Interatively traverse the tree using the cursor mechanism */
    count = 0;
    do {
        if (etree_getcursor(ep, &addr, field_desc, payload) != 0) {
            fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));
            exit(-1);
        } 
		if(addr.type != 0){
			//printf("leafnode  %d \n", addr.type);
			if( checkBalancing(ep, addr)){ //mark as imbalanced
				//k = j;
				printf("The tree is unbalanced \n");
				exit(-1);
			}
 
		}

        count++;
    } while (etree_advcursor(ep) == 0);


    free (payload);

    if ((err = etree_errno(ep)) != ET_END_OF_TREE) {
        /* make sure that the cursor terminates correctly */
        fprintf(stderr, "%s\n", etree_strerror(err));
        exit(-1);
    }        

	printf("The tree is balanced \n");
    return count;
}

/* $end traverse */
