#!/bin/sh

rm tree.diat
./txt2etree tree.diat < test/diat.txt
