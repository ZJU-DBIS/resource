#include <stdio.h>
#include <stdlib.h>
#include "etree.h"
#include <math.h>
#include <stdbool.h>

#define ODOT_MAXLEVEL 10

#define PI 3.14159265
#define MAX_SIZE 1024

int refineCount = 0;
int newOctants = 0;
int countBalance = 0;
int angle;


typedef struct payload_t {
    int32_t val;
    char tag;
} payload_t;

int not_balance(etree_t *ep, etree_addr_t root);
int not_balance1(etree_t *ep, etree_addr_t root);
void refine_balance(etree_t *ep, etree_addr_t root, int depth);
void traverse_and_balance(char * filename);
void traverse_and_balance1(char * filename);
void traverse_and_refine(etree_t *ep_read, etree_t *ep, int theta);
void traverse_and_refine_value(etree_t *ep_read, etree_t *ep);
int refine_pred(etree_addr_t addr, int payload, int theta);
int refine_value_pred(etree_addr_t addr, int payload, int value);
int traverse(etree_t *ep);
void refine(etree_t *ep, etree_addr_t root, int theta);
void refine_value(etree_t *ep, etree_addr_t root, int value);
void multi_traverse_and_refine(char * file, int theta);
 
int main(int argc, char **argv)
{
    etree_t *ep, *ep_read;
    int count;
    char *filename;
	char * mode;
	mode = argv[2];

    if (argc != 3) {
        fprintf(stderr, "Usage: %s <etree> <type of refinement> \n", argv[0]);
        exit(0);
    }
    filename = argv[1];

    /* Create an empty 3d etree with an integer record */
    ep_read = etree_open(filename, O_RDONLY, 0, 0, 3);
    if (ep_read == NULL) {
        fprintf(stderr, "Could not open etree file %s\n", filename);
        exit(1);
    }

    ep = etree_open(filename, O_RDWR, 1 , sizeof(payload_t), 3);
    if (ep == NULL) {
        fprintf(stderr, "Could not open etree file %s\n", filename);
        exit(1);
    }

/*
    // Register the schema for the etree to make it portable

    if (etree_registerschema(ep, "int32_t val; char tag;") != 0) {
        fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));
        exit(1);
    }
*/
    /* Recursively refine the root octant */
    /* $begin callrefine */
	if(*mode == 'l'){
    	traverse_and_refine(ep_read, ep, 18);
	}else if (*mode == 'v'){
		traverse_and_refine_value(ep_read, ep);
	}else{
	    fprintf(stderr, "Usage:  <etree> <%s type of refinement> \n", argv[2]);
	}
    count = traverse(ep);
    fprintf(stderr, "The tree has %d octants\n", count);
    /* $end callrefine */

    /* Clean up */
	etree_close(ep);

	 /* Rotate 11 times  to make large input 
	for(angle = 0; angle < 360; angle += 5){
		multi_traverse_and_refine(filename, angle);
	} */
	

	/* Try to balance the tree */
	traverse_and_balance(filename);	
	traverse_and_balance1(filename);
    exit(0);
}




/* Refine thee cell under predicate */
void refine(etree_t *ep, etree_addr_t root, int theta)
{
    
	int i, j, k, incr;
    etree_addr_t child;
    static int val = 0;
    payload_t payload;

    if (root.type != ETREE_LEAF) return;
	if(root.level >= ODOT_MAXLEVEL) return;

    /* $begin refine */
    /* Check the terminating conditions for the recursion */
    if (!refine_pred(root, val, theta)) {
		return;
	}
    /* Make the root an interior node */
    if (etree_delete(ep, root) != 0) {
        fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));

        exit(1);
    }
    root.type = ETREE_INTERIOR;
    payload.val = val;  
    payload.tag = 'A' + (root.level - (ODOT_MAXLEVEL - 2));
    etree_insert(ep, root, &payload);

    /* Edge of octant at level (ETREE_MAXLEVEL-k) is 2^k ticks */
    child.level = root.level + 1;
    child.type = ETREE_LEAF;
    incr = 1 << (ODOT_MAXLEVEL - child.level);
	
	refineCount++;
    /* Recursively expand the children in z-order */
    for (k = 0; k <= incr; k += incr) {
        child.z = root.z + k;
        for (j = 0; j <= incr; j += incr) {
            child.y = root.y + j;
            for (i = 0; i <= incr; i += incr) {
                child.x = root.x + i;
                payload.val = ++val;
                payload.tag = 'A' + (child.level - (ODOT_MAXLEVEL - 2));
	        //printf("x:%d, y:%d, z:%d  , incr: %d, root level : %d, child level: %d ,c = %d \n", child.x, child.y, child.z, incr, root.level,child.level, c);
                etree_insert(ep, child, &payload);
				newOctants++;
                refine(ep, child, theta);
            }
        }
    }

    return;
}


/* 
 * traverse - Walk the tree in z-order (pre-order)
*begin traverse
 */
void traverse_and_refine(etree_t *ep_read, etree_t *ep, int theta)
{
    etree_addr_t addr;
    void* payload;
    etree_error_t err;
    const char* field_desc = NULL;
    char* schema;

    schema = etree_getschema(ep_read);

    if (schema != NULL) {
	field_desc = "*";
	free (schema);
    }

    /* Get the initial cursor */
    addr.x = addr.y = addr.z = addr.t = addr.level = 0;
    if (etree_initcursor(ep_read, addr) != 0) {
        fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep_read)));
        exit(-1);
    }

    payload = malloc (etree_getpayloadsize(ep_read));

    /* Interatively traverse the tree using the cursor mechanism */
    do {
        if (etree_getcursor(ep_read, &addr, field_desc, payload) != 0) {
            fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));
            exit(-1);
        } 

        //printf("addr.x=%d, addr.y=%d, addr.z=%d, level=%d, type=%d\n", addr.x, addr.y, addr.z, addr.level, addr.type);

        refine(ep, addr, theta);

    } while (etree_advcursor(ep_read) == 0);
	//printf("Octants need to be refined = %d , New Octants created = %d  \n" , refineCount, newOctants);

    free (payload);

    if ((err = etree_errno(ep_read)) != ET_END_OF_TREE) {
        /* make sure that the cursor terminates correctly */
        fprintf(stderr, "%s\n", etree_strerror(err));
        exit(-1);
    }        
}
/* $end traverse */






/* Refine thee cell under valued base predicate */
void refine_value(etree_t *ep, etree_addr_t root, int value)
{
	int i, j, k, incr;
    etree_addr_t child;
    static int val = 0;
    payload_t payload;	
    if (root.type != ETREE_LEAF) return;
	if(root.level >= ODOT_MAXLEVEL - 3) return;
    /* $begin refine */
    /* Check the terminating conditions for the recursion */
    if (!refine_value_pred(root, val, value)) {
		return;
	}
    /* Make the root an interior node */
    if (etree_delete(ep, root) != 0) {
        fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));

        exit(1);
    }
    root.type = ETREE_INTERIOR;
    payload.val = val;  
    payload.tag = '0' + value;
    etree_insert(ep, root, &payload);

    /* Edge of octant at level (ETREE_MAXLEVEL-k) is 2^k ticks */
    child.level = root.level + 1;
    child.type = ETREE_LEAF;
    incr = 1 << (ODOT_MAXLEVEL - child.level);
	
	refineCount++;
    /* Recursively expand the children in z-order */
    for (k = 0; k <= incr; k += incr) {
        child.z = root.z + k;
        for (j = 0; j <= incr; j += incr) {
            child.y = root.y + j;
            for (i = 0; i <= incr; i += incr) {
                child.x = root.x + i;
                payload.val = ++val;
                payload.tag = value + '0';
	        //printf("x:%d, y:%d, z:%d  , incr: %d, root level : %d, child level: %d ,c = %d \n", child.x, child.y, child.z, incr, root.level,child.level, c);
                etree_insert(ep, child, &payload);
				//newOctants++;
                refine_value(ep, child, value);
            }
        }
    }

    return;
}


/* 
 * traverse  and refine valued base- Walk the tree in z-order (pre-order)
*begin traverse
 */
void traverse_and_refine_value(etree_t *ep_read, etree_t *ep)
{
    etree_addr_t addr;
    void* payload;
    etree_error_t err;
    const char* field_desc = NULL;
    char* schema;
	int value;

    schema = etree_getschema(ep_read);

    if (schema != NULL) {
	field_desc = "*";
	free (schema);
    }

    /* Get the initial cursor */
    addr.x = addr.y = addr.z = addr.t = addr.level = 0;
    if (etree_initcursor(ep_read, addr) != 0) {
        fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep_read)));
        exit(-1);
    }

    payload = malloc (etree_getpayloadsize(ep_read));

    /* Interatively traverse the tree using the cursor mechanism */
    do {
        if (etree_getcursor(ep_read, &addr, field_desc, payload) != 0) {
            fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));
            exit(-1);
        } 
		payload_t p = *(payload_t*) payload;
		char c = p.tag;
		value = (int) (c - '0');
        refine_value(ep, addr, value);
    } while (etree_advcursor(ep_read) == 0);
    free (payload);

    if ((err = etree_errno(ep_read)) != ET_END_OF_TREE) {
        /* make sure that the cursor terminates correctly */
        fprintf(stderr, "%s\n", etree_strerror(err));
        exit(-1);
    }        
}
/* $end traverse */



 /* multi_ traverse - Walk the tree in z-order (pre-order) */
void multi_traverse_and_refine(char * file, int theta)
{
 	char * filename;
	filename = file;
    etree_addr_t addr;
    void* payload;
    etree_error_t err;
    const char* field_desc = NULL;
    char* schema;
	etree_t *ep, *ep_read;
	ep_read = etree_open(filename, O_RDONLY, 0, 0, 3);
    if (ep_read == NULL) {
        fprintf(stderr, "Could not open etree file %s\n", filename);
        exit(1);
    }

    ep = etree_open(filename, O_RDWR, 1, sizeof(payload_t), 3);
    if (ep == NULL) {
        fprintf(stderr, "Could not open etree file %s\n", filename);
        exit(1);
    }
	
    schema = etree_getschema(ep_read);

    if (schema != NULL) {
	field_desc = "*";
	free (schema);
    }

    addr.x = addr.y = addr.z = addr.t = addr.level = 0;
    if (etree_initcursor(ep_read, addr) != 0) {

        fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep_read)));
        exit(-1);
    }
    payload = malloc (etree_getpayloadsize(ep_read));

    do {
        if (etree_getcursor(ep_read, &addr, field_desc, payload) != 0) {
            fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));
            exit(-1);
        }
 
		refine(ep, addr, theta);

    } while (etree_advcursor(ep_read) == 0);
    free (payload);
	etree_close(ep);	
    if ((err = etree_errno(ep_read)) != ET_END_OF_TREE) {
        fprintf(stderr, "%s\n", etree_strerror(err));
        exit(-1);
    }  
    
}



/* refine function for balancing the etree */
void refine_balance(etree_t *ep, etree_addr_t root, int depth)
{
	int i, j, k, incr;
    etree_addr_t child;
    static int val = 0;
    payload_t payload;
	if(depth == 0) return;
	if (root.type != ETREE_LEAF) return ;
	if(root.level >= ODOT_MAXLEVEL) return;

    /* Make the root an interior node */
    if (etree_delete(ep, root) != 0) {
        fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));
        exit(1);
    }
    root.type = ETREE_INTERIOR;
    payload.val = val;  
    payload.tag = 'A' + (root.level - (ODOT_MAXLEVEL - 2));
    etree_insert(ep, root, &payload);

    /* Edge of octant at level (ETREE_MAXLEVEL-k) is 2^k ticks */
    child.level = root.level + 1;
    child.type = ETREE_LEAF;
    incr = 1 << (ODOT_MAXLEVEL - child.level);
	depth--;
    /* Recursively expand the children in z-order */
    for (k = 0; k <= incr; k += incr) {
        child.z = root.z + k;
        for (j = 0; j <= incr; j += incr) {
            child.y = root.y + j;
            for (i = 0; i <= incr; i += incr) {
                child.x = root.x + i;
                payload.val = ++val;
                payload.tag = '0' + 0;
                etree_insert(ep, child, &payload);
                //refine_balance(ep, child, depth);
            }
        }
    }

	
    return;
}


/* check a cell need to be refine to maintain balance */
int not_balance(etree_t *ep, etree_addr_t root){
	int octlevel = root.level;
	int result; //find neighbor result
	int nlevel; //neigbor level
    int dir;  //direction
	int diff;

		if (root.type != ETREE_LEAF) return 0;
		if(root.level >= ODOT_MAXLEVEL) return 0;
	 for(dir = 0; dir < 26; dir++){
		 etree_addr_t * naddr;
		 naddr = malloc(sizeof(etree_addr_t));
		 result = etree_findneighbor(ep, root, dir, naddr, NULL, NULL); 
		 if(result == 0){
			nlevel = naddr->level;
				if((nlevel- octlevel) > 1){
					//printf(	"Refine octant \n");	
					diff = nlevel- octlevel;
					refine_balance(ep, root, diff - 1);
					free(naddr);
					return 1;
				}
				free(naddr);
		}else{
 			free(naddr);
		}
	}
	return 0;
}


/* check a cell need to be refine to maintain balance */
int not_balance1(etree_t *ep, etree_addr_t root){
	int octlevel = root.level;
	int result; //find neighbor result
	int nlevel; //neigbor level
    int dir;  //direction
	int diff;

		if (root.type != ETREE_LEAF) return 0;
		if(root.level > ODOT_MAXLEVEL) return 0;
	 for(dir = 0; dir < 26; dir++){
		 etree_addr_t * naddr;
		 naddr = malloc(sizeof(etree_addr_t));
		 result = etree_findneighbor(ep, root, dir, naddr, NULL, NULL); 
		 if(result == 0){
			nlevel = naddr->level;
				if((octlevel - nlevel) > 1){
					//printf(	"Refine neighbor \n");	
					diff = octlevel - nlevel;
					refine_balance(ep, * naddr, diff - 1);
					free(naddr);
					return 1;
				} 
				free(naddr);
		}else{
 			free(naddr);
		}
	}
	return 0;
}



/* traverse and do balancing the tree */
void traverse_and_balance(char* file){
	int notBalance = 0;
	char * filename;
	filename = file;
    etree_addr_t addr;
    void* payload;
    etree_error_t err;
    const char* field_desc = NULL;
    char* schema;
	etree_t *ep, *ep_read;
	ep_read = etree_open(filename, O_RDONLY, 0, 0, 3);
    if (ep_read == NULL) {
        fprintf(stderr, "Could not open etree file %s\n", filename);
        exit(1);
    }

    ep = etree_open(filename, O_RDWR, 1, sizeof(payload_t), 3);
    if (ep == NULL) {
        fprintf(stderr, "Could not open etree file %s\n", filename);
        exit(1);
    }
	
    schema = etree_getschema(ep_read);

    if (schema != NULL) {
	field_desc = "*";
	free (schema);
    }

    /* Get the initial cursor */
    addr.x = addr.y = addr.z = addr.t = addr.level = 0;
    if (etree_initcursor(ep_read, addr) != 0) {

        fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep_read)));
        exit(-1);
    }

    payload = malloc (etree_getpayloadsize(ep_read));

    /* Interatively traverse the tree using the cursor mechanism */
    do {
        if (etree_getcursor(ep_read, &addr, field_desc, payload) != 0) {
            fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));
            exit(-1);
        } 
		/* to see if a cell need to be refine */       
			if(not_balance(ep, addr)){  
				notBalance = 1;	
			}
    } while (etree_advcursor(ep_read) == 0);
    free (payload);
	etree_close(ep);	
    if ((err = etree_errno(ep_read)) != ET_END_OF_TREE) {
        fprintf(stderr, "%s\n", etree_strerror(err));
        exit(-1);
    }  
	
	if(notBalance) 
		traverse_and_balance(filename);  
    
}


/* traverse and do balancing the tree */
void traverse_and_balance1(char* file){
	int notBalance = 0;
	char * filename;
	filename = file;
    etree_addr_t addr;
    void* payload;
    etree_error_t err;
    const char* field_desc = NULL;
    char* schema;
	etree_t *ep, *ep_read;
	ep_read = etree_open(filename, O_RDONLY, 0, 0, 3);
    if (ep_read == NULL) {
        fprintf(stderr, "Could not open etree file %s\n", filename);
        exit(1);
    }

    ep = etree_open(filename, O_RDWR, 1, sizeof(payload_t), 3);
    if (ep == NULL) {
        fprintf(stderr, "Could not open etree file %s\n", filename);
        exit(1);
    }
	
    schema = etree_getschema(ep_read);

    if (schema != NULL) {
	field_desc = "*";
	free (schema);
    }


    addr.x = addr.y = addr.z = addr.t = addr.level = 0;
    if (etree_initcursor(ep_read, addr) != 0) {

        fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep_read)));
        exit(-1);
    }

    payload = malloc (etree_getpayloadsize(ep_read));


    do {
        if (etree_getcursor(ep_read, &addr, field_desc, payload) != 0) {
            fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));
            exit(-1);
        } 

			if(not_balance1(ep, addr)){  
				notBalance = 1;	
			}
    } while (etree_advcursor(ep_read) == 0);
    free (payload);
	etree_close(ep);
	
    if ((err = etree_errno(ep_read)) != ET_END_OF_TREE) {
        fprintf(stderr, "%s\n", etree_strerror(err));
        exit(-1);
    }  
	
	if(notBalance)
		traverse_and_balance1(filename);  
 	   
}



/* z- range of the mesh to see if cell need to be refine */
bool z_inside(uint32_t z){
	double input_z [2] = {480 , 530};
	//return if num1 <= z <= num2
	return ((z >= input_z[0]) && (z <= input_z[1]));
}



/*get new x0, y0 and R to of the mesh (or disk  in 3D),
initial x = 512, y = 768 , z = 512 and R = 150 */
uint32_t * get_mesh(double theta){
	uint32_t * mesh = malloc(3 * sizeof(uint32_t));

// x0' = x0*cos(theta)	- y0*sin(theta)
	mesh[0] = (uint32_t)(512 + 150*sin(theta)) ; 

// y0' = x0*cos(theta)	+ y0*sin(theta)
	mesh [1] = (uint32_t)(512 + 150*cos(theta)) ;


//R
	mesh[2] = 150; 	

	return mesh;
}

//return if point is inside the mesh or not
bool point_inside_mesh(uint32_t point[3], uint32_t * mesh){
	uint32_t x, y, z;
	uint32_t x0, y0, R;
	bool inside;
	//mesh
	x0 = mesh[0];
	y0 = mesh[1];
	R = mesh[2];
	//point to check
	x = point[0];
	y = point[1];
	z = point [2];
	//return true if point is inside mesh, otherwise return false
	inside = (((x - x0)*(x-x0) + (y - y0)*(y - y0)) <= R*R) && z_inside(z);
	return (inside);

}

/* helper funct to see if the cell is in the mesh - by compare coordinates of all corners of cell with the function of the mesh */
bool inside_mesh(etree_addr_t addr, int theta){
	uint32_t  p1[3], p2[3], p3[3], p4[3], p5[4], p6[4], p7[4], p8[3];
	int size, level;
	size = MAX_SIZE;
	level = addr.level;
	while(level > 0){
		size /= 2;
		level--;
	}

	//mesh 
	uint32_t * mesh ;
	double theta_;
	theta_ = (double) (theta*PI/180); //convert to radian
	mesh = get_mesh(theta_);
	//point - x, y, z
	p1[0] = addr.x;
	p1[1] = addr.y;
	p1[2] = addr.z;

	p2[0] = addr.x + size;
	p2[1] = addr.y;
	p2[2] = addr.z;
	
	p3[0] = addr.x + size;
	p3[1] = addr.y + size;
	p3[2] = addr.z;
	
	p4[0] = addr.x;
	p4[1] = addr.y + size;
	p4[2] = addr.z;

	p5[0] = addr.x;
	p5[1] = addr.y;
	p5[2] = addr.z + size;

	p6[0] = addr.x + size;
	p6[1] = addr.y ;
	p6[2] = addr.z + size;

	p7[0] = addr.x + size;
	p7[1] = addr.y + size;
	p7[2] = addr.z + size;

	p8[0] = addr.x ;
	p8[1] = addr.y + size;
	p8[2] = addr.z + size;

	//case 1: all points inside the mesh we wont refine

	if(point_inside_mesh(p1, mesh) && point_inside_mesh(p2, mesh) &&
		 point_inside_mesh(p3, mesh) && point_inside_mesh(p4, mesh) &&
		 point_inside_mesh(p5, mesh)&& point_inside_mesh(p6, mesh) && 
		 point_inside_mesh(p7, mesh) && point_inside_mesh(p8, mesh)) 	{
		free(mesh);
		return false;
	}

	//case 2: all points outside mesh, wont refine	
	if(!point_inside_mesh(p1, mesh) && !point_inside_mesh(p2, mesh) &&
		 !point_inside_mesh(p3, mesh) && !point_inside_mesh(p4, mesh) &&
		 !point_inside_mesh(p5, mesh) && !point_inside_mesh(p6, mesh) && 
		 !point_inside_mesh(p7, mesh) && !point_inside_mesh(p8, mesh)){
	 	free(mesh);
		return false;
	}	
		free(mesh);
	return true;
}

/* predicate valued base define octant should be refined or not */
int refine_value_pred(etree_addr_t addr, int payload, int value){
	if(value != 0) return 1;
	return 0;
}

/* predicate define a octant should be modified or not */

int refine_pred(etree_addr_t addr, int payload, int theta)
{
	bool in;
	in = inside_mesh(addr, theta);
	if(in)
		return 1;
    else 
		return 0;
}
