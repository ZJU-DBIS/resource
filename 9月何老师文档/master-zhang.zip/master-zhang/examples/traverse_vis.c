#include <stdio.h>
#include <stdlib.h>
#include "etree.h"
#include "schemax.h"

#define LEN 1024

/**
 * eh_etree_straddr - Format a string representation of an etree address
 */
char* eh_etree_straddr_5(int dim, char* buf, const etree_addr_t* addr)
{
    if (dim == 3) { /* 3d case */
        sprintf(buf, "%d %d %d 0",
                addr->x, addr->y, addr->z);
    }
  
    return buf;
}

char* eh_etree_straddr_6(int dim, char* buf, const etree_addr_t* addr)
{
    int unit = 1;

    if (dim == 3) { /* 3d case */
        unit = LEN >> addr->level;
        sprintf(buf, "%d %d %d 0",
                addr->x + unit, addr->y, addr->z);
    }
    
    return buf;
}

char* eh_etree_straddr_8(int dim, char* buf, const etree_addr_t* addr)
{
    int unit = 1;

    if (dim == 3) { /* 3d case */
        unit = LEN >> addr->level;
        sprintf(buf, "%d %d %d 0",
                addr->x, addr->y, addr->z + unit);
    }
    
    return buf;
}

char* eh_etree_straddr_7(int dim, char* buf, const etree_addr_t* addr)
{
    int unit = 1;

    if (dim == 3) { /* 3d case */
        unit = LEN >> addr->level;
        sprintf(buf, "%d %d %d 0",
                addr->x + unit, addr->y, addr->z + unit);
    }
    
    return buf;
}

char* eh_etree_straddr_1(int dim, char* buf, const etree_addr_t* addr)
{
    int unit = 1;

    if (dim == 3) { /* 3d case */
        unit = LEN >> addr->level;
        sprintf(buf, "%d %d %d 0",
                addr->x, addr->y + unit, addr->z);
    }
    
    return buf;
}

char* eh_etree_straddr_4(int dim, char* buf, const etree_addr_t* addr)
{
    int unit = 1;

    if (dim == 3) { /* 3d case */
        unit = LEN >> addr->level;
        sprintf(buf, "%d %d %d 0",
                addr->x, addr->y + unit, addr->z + unit);
    }
    
    return buf;
}

char* eh_etree_straddr_2(int dim, char* buf, const etree_addr_t* addr)
{
    int unit = 1;

    if (dim == 3) { /* 3d case */
        unit = LEN >> addr->level;
        sprintf(buf, "%d %d %d 0",
                addr->x + unit, addr->y + unit, addr->z);
    }
    
    return buf;
}

char* eh_etree_straddr_3(int dim, char* buf, const etree_addr_t* addr)
{
    int unit = 1;

    if (dim == 3) { /* 3d case */
        unit = LEN >> addr->level;
        sprintf(buf, "%d %d %d 0",
                addr->x + unit, addr->y + unit, addr->z + unit);
    }
    
    return buf;
}

/* Check balancing of the tree */
int checkBalancing(etree_t *ep, etree_addr_t root){

	int octlevel = root.level;
	int result; //find neighbor result
	int nlevel; //neigbor level
    int dir;  //direction
	
	 for(dir = 8; dir < 26; dir++){
		 etree_addr_t * naddr;
		 naddr = malloc(sizeof(etree_addr_t));
		 result = etree_findneighbor(ep, root, dir, naddr, NULL, NULL); 
		if(result == 0){
			nlevel = naddr->level;
			if((nlevel - octlevel) > 1 || (octlevel - nlevel) > 1){

				printf("Level of octant = %d and level of octan's neighbor  = %d  in direction %d \n", octlevel, nlevel, dir);

 printf("Octant: addr.x=%d, addr.y=%d, addr.z=%d, level=%d, type=%d\n", root.x, root.y, root.z, root.level, root.type);
 printf("Neighbor: addr.x=%d, addr.y=%d, addr.z=%d, level=%d, type=%d\n", naddr->x, naddr->y, naddr->z, naddr->level, naddr->type);
				

				return 1;
				free(naddr);
			}
		}
 		free(naddr);
	}
	return 0;

}





/* 
 * traverse - Walk the tree in z-order (pre-order)
 */
/* $begin traverse */
int traverse(etree_t *ep)
{
    etree_addr_t addr;
    void* payload;
    int count;
    char buf[ETREE_MAXBUF];
    etree_error_t err;
    const char* field_desc = NULL;
    char* schema;
    int i;
	//int j;


    schema = etree_getschema(ep);

    if (schema != NULL) {
	field_desc = "*";
	free (schema);
    }

    /* Get the initial cursor */
    addr.x = addr.y = addr.z = addr.t = addr.level = 0;
    if (etree_initcursor(ep, addr) != 0) {
        fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));
        exit(-1);
    }

    payload = malloc (etree_getpayloadsize(ep));

    /* Interatively traverse the tree using the cursor mechanism */
    count = 0;
    do {
        if (etree_getcursor(ep, &addr, field_desc, payload) != 0) {
            fprintf(stderr, "%s\n", etree_strerror(etree_errno(ep)));
            exit(-1);
        } 
		 /*
		j = checkBalancing(ep, addr);
		if(j){ //mark as imbalanced
			k = j;
			printf("The tree is imbalanced \n");
			exit(-1);
continue;
		}
 */


        count++;

        printf("%s", eh_etree_straddr_1(ep->dimensions, buf, &addr));
	putchar('\n');
        printf("%s", eh_etree_straddr_2(ep->dimensions, buf, &addr));
	putchar('\n');
        printf("%s", eh_etree_straddr_3(ep->dimensions, buf, &addr));
	putchar('\n');
        printf("%s", eh_etree_straddr_4(ep->dimensions, buf, &addr));
	putchar('\n');
        printf("%s", eh_etree_straddr_5(ep->dimensions, buf, &addr));
	putchar('\n');
        printf("%s", eh_etree_straddr_6(ep->dimensions, buf, &addr));
	putchar('\n');
        printf("%s", eh_etree_straddr_7(ep->dimensions, buf, &addr));
	putchar('\n');
        printf("%s", eh_etree_straddr_8(ep->dimensions, buf, &addr));
	//schemax_printpayload(ep, payload, stdout);
	putchar('\n');
    } while (etree_advcursor(ep) == 0);


    free (payload);

    if ((err = etree_errno(ep)) != ET_END_OF_TREE) {
        /* make sure that the cursor terminates correctly */
        fprintf(stderr, "%s\n", etree_strerror(err));
        exit(-1);
    }        

    for(i = 1; i <= count * 8; i=i+8) {
        printf("%d %d %d %d %d %d %d %d\n", i, i+1, i+2, i+3, i+4, i+5, i+6, i+7);
    }

    printf("nodes:%d elements:%d\n", count*8, count);
	//printf("The tree is balanced \n");
    return count;
}

/* $end traverse */
