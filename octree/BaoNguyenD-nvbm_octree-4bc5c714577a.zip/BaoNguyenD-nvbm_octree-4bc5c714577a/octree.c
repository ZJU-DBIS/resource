/* Implementation of  Octree  with NVBM */
/* Bao Nguyen  & Dr. Xuechen Zhang*/
/* Reference code for octree from Gerris Flow Solver */
/* http://gfs.sourceforge.net/wiki/index.php/Main_Page */

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "octree.h"
#include <glib.h>
#include <stdlib.h>
#include <sys/time.h>
# include <mpi.h>
#define FTT_2D FALSE
#define PI 3.14159265
#define MAX_SIZE  1024
#define MAX_BUFFER 2045
#define MAX_LEVEL 8
#define NVRAM 1
#define RAMBOUND 10000     //Define threshold to merge sub-tree on DRAM to NVBM 
#define DEBUG 1
#define LOCATION 1
//#define HYPERBOLOID 1   //Uncomment to test with other mesh type
//#define VALUE 1		 //Uncomment to text with refine mesh base on value
//#define MULTI 1		 //Uncomment to test with multi-rotation
//#define EXTRACTMESH 1  //Uncomment to print out the mesh to file 
#define MPI 1


//Some global variables to keep tracks of interested numbers
int count = 0; //to print tree
int countOut = 0; //to extract mesh
int coarsencount = 0; 
int cleancount = 0; //check deleted cell
int checkCell = 0;
int dramcell = 0; //number of cell in Dram
int nvramcell = 0; //number of cell in nvram
gboolean balance = TRUE; //keep track of balance of the tree
gboolean pm_octree = 0; 
int deletedCell = 0; //number of cell marked as deleted
int dramcount = 0;   //bound for DRAM (number of cell stored in Dram)
int nvrambound = 0;

#ifdef MPI
int rank, /* rank of each process */ size /*total processes */;
int deep; /* how deep the partition tree should start at */
int branches_on_deep; /*how many branches of a deep level */
int branch_each_processor; //determine number of branches that a processor should work on */
int branch_last_processor; //number of branches a last processor need to work on */
int branch_number_start; //The number of branch a processor need to start on Total number of branches in a level
int branch_number_end; //end of branches to work on
int branch_count; 		//To keep track of branches on a deep level
#endif

typedef struct _FttRootCell FttRootCell; //rootcell
//struct to hold coordinates and value of a cell
typedef struct address_t{
	double x;
	double y;
	double z;
	int type;
	int level;
	int val;
    char tag;
} address_t;

//initial coordinates of a cell at root
static double coords[FTT_CELLS][3] =
#if FTT_2D
 {{-1., 1.,0.},
  { 1., 1.,0.},
  {-1.,-1.,0.},
  { 1.,-1.,0.}};
#else  /* FTT_3D */
 {{-1., 1., 1.},
  { 1., 1., 1.},
  {-1.,-1., 1.},
  { 1.,-1., 1.},
  {-1., 1.,-1.},
  { 1., 1.,-1.},
  {-1.,-1.,-1.},
  { 1.,-1.,-1.}};
#endif /* FTT_3D */

void print_octan_points(FttCell * root){

	g_return_if_fail (root != NULL);
	double size;
	double x,y,z;
	guint flag;	
	if(FTT_CELL_IS_LEAF(root) /*&& (root->data)*/ ){
		//if it is leave node
		flag = FTT_CELL_ID (root);
		size = ftt_cell_size (root)/2.;
		x = root->parent->pos.x + coords[flag][0]*size;
		y = root->parent->pos.y + coords[flag][1]*size;
		z = root->parent->pos.z + coords[flag][2]*size;
		countOut += 1;
		//print 8 points of an octants
		printf("%g %g %g 0\n", x - size, y + size, z + size);
		printf("%g %g %g 0\n", x + size, y + size, z + size);
		printf("%g %g %g 0\n", x + size, y + size, z - size);
		printf("%g %g %g 0\n", x - size, y + size, z - size);
		printf("%g %g %g 0\n", x - size, y - size, z + size);
		printf("%g %g %g 0\n", x + size, y - size, z + size);
		printf("%g %g %g 0\n", x + size, y - size, z - size);
		printf("%g %g %g 0\n", x - size, y - size, z - size);
	}
	 if(!FTT_CELL_IS_LEAF (root)) {
			FttOct * children = root->children;
			countOut += 1;
			size = ftt_cell_size (root)/2.;
			//print 8points of an octant
			printf("%g %g %g 0\n",children->pos.x - size, children->pos.y + size, children->pos.z + size);
			printf("%g %g %g 0\n",children->pos.x + size, children->pos.y + size, children->pos.z + size);
			printf("%g %g %g 0\n",children->pos.x + size, children->pos.y + size, children->pos.z - size);
			printf("%g %g %g 0\n",children->pos.x - size, children->pos.y + size, children->pos.z - size);
			printf("%g %g %g 0\n",children->pos.x - size, children->pos.y - size, children->pos.z + size);
			printf("%g %g %g 0\n",children->pos.x + size, children->pos.y - size, children->pos.z + size);
			printf("%g %g %g 0\n",children->pos.x + size, children->pos.y - size, children->pos.z - size);
			printf("%g %g %g 0\n",children->pos.x - size, children->pos.y - size, children->pos.z - size);
    		guint n;
				for (n = 0; n < FTT_CELLS; n++) {
		  			FttCell * c;
					c =  &children->cell[n];
					print_octan_points(c);
				}	
	}

}

/* 
 * Export node and elment relationship to output - or we call it as extract mesh
 * Given a root of a tree root, write to a text file
 */

void tree2file(FttCell * rootcell){
	int i = 0;
	print_octan_points(rootcell);
	for(i = 1; i <= countOut * 8; i=i+8) {
        printf("%d %d %d %d %d %d %d %d\n", i, i+1, i+2, i+3, i+4, i+5, i+6, i+7);
    }
	printf("nodes:%d elements:%d\n", countOut*8, countOut);
	countOut = 0;
}


/* 
 * Print the tree in pre-order
 * @FttCell root: Root of a tree
 */
void print_pre_order(FttCell * root){
	g_return_if_fail (root != NULL);
	if(FTT_CELL_IS_LEAF(root) && (!root->parent)){
		return;
	} 
	double size;
	double x,y,z;
	guint flag;	
	address_t addr;
	int type;
	//char tag = 'A';
	int level = 0;
	level = ftt_cell_level (root);	
	if(root->nvramflag == 1)nvramcell++;
	if(root->nvramflag == 0)dramcell++;	
	if(root->deleted == 1) deletedCell++;

	if(root->data!=NULL){
		addr= *(address_t*)root->data;
	}
	if(FTT_CELL_IS_LEAF(root) /*&& (root->data)*/){
		//if it is leave node
		flag = FTT_CELL_ID (root);
		size = ftt_cell_size (root)/2.;
		x = root->parent->pos.x + coords[flag][0]*size;
		y = root->parent->pos.y + coords[flag][1]*size;
		z = root->parent->pos.z + coords[flag][2]*size;
		count += 1;
		type = 1;
		//printf("%g %g %g %d %d %d %c\n", x, y, z, level, addr.type, count, tag);
		printf("%g %g %g %d %d %d %c\n", x, y, z, level, type, count, addr.tag);
	}
	 if(!FTT_CELL_IS_LEAF (root)) {
			FttOct * children = root->children;
			count += 1;
			level = ftt_cell_level (root);
			printf("%g %g %g %d %d %d %c\n",children->pos.x, children->pos.y, children->pos.z,level, addr.type, count, addr.tag);
    		guint n;
				for (n = 0; n < FTT_CELLS; n++) {
		  			FttCell * c;
					c =  &children->cell[n];
					print_pre_order(c);
				}	
	}
}


/* 
 * Print the tree in post-order
 * @FttCell root: Root of a tree
 */
void print_post_order(FttCell * root){
	g_return_if_fail (root != NULL);
	double size;
	double x,y,z;
	guint flag;
	address_t addr;

	char tag = 'A';
	int level = 0;
	level = ftt_cell_level (root);	
	if(root->data!=NULL){
		addr= *(address_t*)root->data;
	}
	 if(!FTT_CELL_IS_LEAF (root)) {
			FttOct * children = root->children;
			count += 1;
    		guint n;
				for (n = 0; n < FTT_CELLS; n++) {
		  			FttCell * c = NULL;
					c =  &children->cell[n];
					print_post_order(c);
				}	
			printf("%g %g %g %d %d %c\n",children->pos.x, children->pos.y, children->pos.z,level, addr.type,  tag);
		}
		
		if(FTT_CELL_IS_LEAF(root) /*&& (root->data)*/){
		//if it is leave node
			count += 1;
			flag = FTT_CELL_ID (root);
			size = ftt_cell_size (root)/2.;
			x = root->parent->pos.x + coords[flag][0]*size;
			y = root->parent->pos.y + coords[flag][1]*size;
			z = root->parent->pos.z + coords[flag][2]*size;
			printf("%g %g %g %d %d %c\n", x, y, z, level, addr.type, tag);
		}

}


/* 
 * Return the size of a cell bases on cell level
 * @guint level : level of a cell
 */
static double ftt_level_size (guint level)
{
  double size = MAX_SIZE;

  while (level) {
    size /= 2.;
    level--;
  }
  return size;
}

//determine the size of the cell
static double ftt_cell_size (const FttCell * cell)
{
  g_return_val_if_fail (cell != NULL, 0.);

  return ftt_level_size (ftt_cell_level (cell));
}

/* 
 * Update level of children of an octree
 * @FttCell parent: root node of octree
 */
static void update_children_level (FttCell * parent)
{
  if (!FTT_CELL_IS_LEAF (parent)) {
    FttOct * oct = parent->children;
    guint n;

    oct->level = ftt_cell_level (parent);
    for (n = 0; n < FTT_CELLS; n++)
      if (!FTT_CELL_IS_DESTROYED (&(oct->cell[n])))
	update_children_level (&(oct->cell[n]));
  }
}

/* 
 * Set the level of a cell by given level
 * @FttCell root: the cell which need to be change
 * @ guint level : given level
 */
void ftt_cell_set_level (FttCell * root, guint level)
{
  g_return_if_fail (root != NULL);
  g_return_if_fail (FTT_CELL_IS_ROOT (root));

  FTT_ROOT_CELL (root)->level = level;
  update_children_level (root);
}

/* 
 * Read the coordinate of cells (2D or 3D) and store in to struct vector
 * @FttCell cell: cell want to read
 * @Fttvector pos: struct - vector to hold coordinate of cell in 2D or 2D
 */
void ftt_cell_pos (const FttCell * cell, FttVector * pos){
	g_return_if_fail (cell != NULL);
 	g_return_if_fail (pos != NULL);
	//if the cell is root 
	if(FTT_CELL_IS_ROOT(cell)){
		*pos = FTT_ROOT_CELL (cell)->pos;
//printf(" root x = %g, y = %g  z= %g\n", pos->x, pos->y,pos->z);

	}else{ //else find the pos of cell in octree
		double size;
		guint n;
		size = ftt_cell_size (cell)/2.;
		n = FTT_CELL_ID (cell);
		pos->x = cell->parent->pos.x + coords[n][0]*size;
		pos->y = cell->parent->pos.y + coords[n][1]*size;
		pos->z = cell->parent->pos.z + coords[n][2]*size;
//printf(" child x = %g, y = %g  z= %g\n", pos->x, pos->y,pos->z);

  }
}

/* 
 * Inline function that find  neighbor of a cell in direction d
 * @FttCell cell: cell to find neighbor of
 * @FttDirection d: direction that go to search the neighbor
 */
static inline FttCell * ftt_cell_neighbor_not_cached (const FttCell * cell,
					FttDirection d)
{
  static gint neighbor_index[FTT_NEIGHBORS][FTT_CELLS]
#if FTT_2D
    = {{1,-1,3,-3},
       {-2,0,-4,2},
       {-3,-4,0,1},
       {2,3,-1,-2}};
#else  /* FTT_3D */
    = {{1,-1,3,-3,5,-5,7,-7},
       {-2,0,-4,2,-6,4,-8,6},
       {-3,-4,0,1,-7,-8,4,5},
       {2,3,-1,-2,6,7,-5,-6},
       {-5,-6,-7,-8,0,1,2,3},
       {4,5,6,7,-1,-2,-3,-4}};
#endif /* FTT_3D */
  gint n;
  FttCell * c;

  g_return_val_if_fail (cell != NULL, NULL);
  g_return_val_if_fail (d < FTT_NEIGHBORS, NULL);

  if (FTT_CELL_IS_ROOT (cell))
    return ((struct _FttRootCell *) cell)->neighbors.c[d];

  n = neighbor_index[d][FTT_CELL_ID (cell)];
  if (n >= 0) /* neighbor belongs to same Oct */
    c = &(cell->parent->cell[n]);
  else {      /* neighbor belongs to neighboring Cell or Oct */
    c = cell->parent->neighbors.c[d];
    if (c != NULL && c->children != NULL)
      c = &(c->children->cell[- n - 1]);
  }
  if (c == NULL || FTT_CELL_IS_DESTROYED (c))
    return NULL;
  else
    return c;
}


/* 
 * Inline function that find and fill in array or neighbor of a cell in direction d
 * @FttCell cell: cell to find neighbor of
 * @FttCellNeighbor : array to hold neighbors
 */
static  inline void ftt_cell_neighbors_not_cached (const FttCell * cell,
				    FttCellNeighbors * neighbors)
{
  static gint neighbor_index[FTT_NEIGHBORS][FTT_CELLS]
#if FTT_2D
    = {{1,-1,3,-3},
       {-2,0,-4,2},
       {-3,-4,0,1},
       {2,3,-1,-2}};
#else  /* FTT_3D */
    = {{1,-1,3,-3,5,-5,7,-7},
       {-2,0,-4,2,-6,4,-8,6},
       {-3,-4,0,1,-7,-8,4,5},
       {2,3,-1,-2,6,7,-5,-6},
       {-5,-6,-7,-8,0,1,2,3},
       {4,5,6,7,-1,-2,-3,-4}};
#endif /* FTT_3D */
  guint n, d;
  struct _FttOct * parent;

  g_return_if_fail (cell != NULL);
  g_return_if_fail (neighbors != NULL);

  if (FTT_CELL_IS_ROOT (cell)) {
    memcpy (neighbors, &((struct _FttRootCell *) cell)->neighbors,
	    sizeof (FttCellNeighbors));
    return;
  }

  parent = cell->parent;
  n = FTT_CELL_ID (cell);
  for (d = 0; d < FTT_NEIGHBORS; d++) {
    gint nn = neighbor_index[d][n];
    FttCell * c;

    if (nn >= 0) /* neighbor belongs to same Oct */
      c = &(parent->cell[nn]);
    else {       /* neighbor belongs to neighboring Cell or Oct */
      c = parent->neighbors.c[d];
      if (c != NULL && c->children != NULL)
	c = &(c->children->cell[- nn - 1]);
    }
    if (c == NULL || FTT_CELL_IS_DESTROYED (c))
      neighbors->c[d] = NULL;
    else
      neighbors->c[d] = c;
  }
}

/* 
 * Inline function that find and fill in array or neighbor of a cell in direction d
 * @FttCell cell: cell to find neighbor of
 * @FttDirection d: direction that go to search the neighbor
 */
static inline FttCell * ftt_cell_neighbor (const FttCell * cell,
			     FttDirection d)
{
  g_return_val_if_fail (cell != NULL, NULL);
  g_return_val_if_fail (d < FTT_NEIGHBORS, NULL);

  if (!FTT_CELL_IS_LEAF (cell))
    return cell->children->neighbors.c[d];

  return ftt_cell_neighbor_not_cached (cell, d);
}


static inline guint ftt_cell_children_direction (const FttCell * cell,
				   FttDirection d,
				   FttCellChildren * children)
{
  struct _FttOct * oct;
  guint i;
#if FTT_2D
  static gint index[FTT_NEIGHBORS_2D][FTT_CELLS/2] =
  {{1, 3},
   {0, 2},
   {0, 1},
   {2, 3}};
#else  /* FTT_3D */
  static gint index[FTT_NEIGHBORS][FTT_CELLS/2] =
  {{1, 3, 5, 7},
   {0, 2, 4, 6},
   {0, 1, 4, 5},
   {2, 3, 6, 7},
   {0, 1, 2, 3},
   {4, 5, 6, 7}};
#endif /* FTT_3D */

  g_return_val_if_fail (cell != NULL, 0);
  g_return_val_if_fail (!FTT_CELL_IS_LEAF (cell), 0);
  g_return_val_if_fail (d < FTT_NEIGHBORS, 0);
  g_return_val_if_fail (children != NULL, 0);

  oct = cell->children;

  for (i = 0; i < FTT_CELLS/2; i++)
    children->c[i] = FTT_CELL_IS_DESTROYED (&(oct->cell[index[d][i]])) ? 
      NULL : &(oct->cell[index[d][i]]);
  return FTT_CELLS/2;
}


/* 
 * Inline function that find and fill in array or neighbor of a cell in direction d
 * @FttCell cell: cell to find neighbor of
 * @FttCellNeighbor : array to hold neighbors
 */
static inline void ftt_cell_neighbors (const FttCell * cell,
			 FttCellNeighbors * neighbors)
{
  g_return_if_fail (cell != NULL);
  g_return_if_fail (neighbors != NULL);

  if (!FTT_CELL_IS_LEAF (cell) && neighbors != &cell->children->neighbors) {
    memcpy (neighbors, &cell->children->neighbors, sizeof (FttCellNeighbors));
    return;
  }
  ftt_cell_neighbors_not_cached (cell, neighbors);
}



/* 
 * Traverse the tree into given level
 * @Fttcell cell : root 
 * @ gint max_depth: given level
 * @ FttCellTraverseFunc func: user define function to pass
 * @  gpointer data: pointer pointer to data
 */
static void cell_traverse_leafs (FttCell * cell,
				 gint max_depth,
				 FttCellTraverseFunc func,
				 gpointer data)
{
  if (max_depth >= 0 && ftt_cell_level (cell) > max_depth)
    return;

  if (FTT_CELL_IS_LEAF (cell))
    (* func) (cell, data);
  if (!FTT_CELL_IS_LEAF (cell)) {
    FttOct * children = cell->children;
    guint n;

    for (n = 0; n < FTT_CELLS; n++) {
      FttCell * c = &(children->cell[n]);

      if (!FTT_CELL_IS_DESTROYED (c))
	cell_traverse_leafs (c, max_depth, func, data);
    }
  }
}

/* 
 * Traverse the tree into given level only with interio nodes in pre order
 * @Fttcell cell : root 
 * @ gint max_depth: given level
 * @ FttCellTraverseFunc func: user define function to pass
 * @  gpointer data: pointer pointer to data
 */
static void cell_traverse_pre_order_nonleafs (FttCell * cell,
					      gint max_depth,
					      FttCellTraverseFunc func,
					      gpointer data)
{
  if (max_depth >= 0 && ftt_cell_level (cell) > max_depth)
    return;

  if (!FTT_CELL_IS_LEAF (cell)) {
    FttCell * parent = ftt_cell_parent (cell);

    (* func) (cell, data);
    /* check that cell has not been deallocated by @func */
    g_assert (parent == NULL || parent->children != NULL);
    if (!FTT_CELL_IS_LEAF (cell)) {
      FttOct * children = cell->children;
      guint n;

      for (n = 0; n < FTT_CELLS; n++) {
	FttCell * c = &(children->cell[n]);
	
	if (!FTT_CELL_IS_DESTROYED (c))
	  cell_traverse_pre_order_nonleafs (c, max_depth, func, data);
      }
    }
  }
}

/* 
 * Traverse the tree into given level only with interio nodes in post-order
 * @Fttcell cell : root 
 * @ gint max_depth: given level
 * @ FttCellTraverseFunc func: user define function to pass
 * @  gpointer data: pointer pointer to data
 */
static void cell_traverse_post_order_nonleafs (FttCell * cell,
					       gint max_depth,
					       FttCellTraverseFunc func,
					       gpointer data)
{
  if (max_depth >= 0 && ftt_cell_level (cell) > max_depth)
    return;

  if (!FTT_CELL_IS_LEAF (cell)) {
    FttOct * children = cell->children;
    guint n;

    for (n = 0; n < FTT_CELLS; n++) {
      FttCell * c = &(children->cell[n]);

      if (!FTT_CELL_IS_DESTROYED (c))
	cell_traverse_post_order_nonleafs (c, max_depth, func, data);
    }

    (* func) (cell, data);
  }
}

/* 
 * Traverse the tree into given level only with leave nodes 
 * @Fttcell cell : root 
 * @ gint max_depth: given level
 * @ FttCellTraverseFunc func: user define function to pass
 * @  gpointer data: pointer pointer to data
 */
static void cell_traverse_level (FttCell * cell,
				 gint max_depth,
				 FttCellTraverseFunc func,
				 gpointer data)
{
  if (ftt_cell_level (cell) == max_depth)
    (* func) (cell, data);
  else if (!FTT_CELL_IS_LEAF (cell)) {
    FttOct * children = cell->children;
    guint n;

    for (n = 0; n < FTT_CELLS; n++) {
      FttCell * c = &(children->cell[n]);

      if (!FTT_CELL_IS_DESTROYED (c))
	cell_traverse_level (c, max_depth, func, data);
    }
  }
}

/* 
 * Traverse the tree into given level only with leave nodes in pre order
 * @Fttcell cell : root 
 * @ gint max_depth: given level
 * @ FttCellTraverseFunc func: user define function to pass
 * @  gpointer data: pointer pointer to data
 */
static void cell_traverse_level_leafs (FttCell * cell,
				       gint max_depth,
				       FttCellTraverseFunc func,
				       gpointer data)
{
  if (ftt_cell_level (cell) == max_depth || FTT_CELL_IS_LEAF (cell))
    (* func) (cell, data);
  else if (!FTT_CELL_IS_LEAF (cell)) {
    FttOct * children = cell->children;
    guint n;

    for (n = 0; n < FTT_CELLS; n++) {
      FttCell * c = &(children->cell[n]);

      if (!FTT_CELL_IS_DESTROYED (c))
	cell_traverse_level_leafs (c, max_depth, func, data);
    }
  }
}


/* 
 * Traverse the tree into given level only with interio nodes in pre order
 * @Fttcell cell : root 
 * @ gint max_depth: given level
 * @ FttCellTraverseFunc func: user define function to pass
 * @  gpointer data: pointer pointer to data
 */
static void cell_traverse_level_non_leafs (FttCell * cell,
					   gint max_depth,
					   FttCellTraverseFunc func,
					   gpointer data)
{
  if (ftt_cell_level (cell) == max_depth && !FTT_CELL_IS_LEAF (cell))
    (* func) (cell, data);
  else if (!FTT_CELL_IS_LEAF (cell)) {
    FttOct * children = cell->children;
    guint n;

    for (n = 0; n < FTT_CELLS; n++) {
      FttCell * c = &(children->cell[n]);

      if (!FTT_CELL_IS_DESTROYED (c))
	cell_traverse_level_non_leafs (c, max_depth, func, data);
    }
  }
}

/* 
 * Traverse the tree into given level 
 * @Fttcell cell : root 
 * @ gint max_depth: given level
 * @ FttCellTraverseFunc func: user define function to pass
 * @  gpointer data: pointer pointer to data
 */
static void cell_traverse_pre_order_all (FttCell * cell,
					 gint max_depth,
					 FttCellTraverseFunc func,
					 gpointer data)
{
	 
  FttCell * parent;
  if (max_depth >= 0 && ftt_cell_level (cell) > max_depth)
    return;

  parent = ftt_cell_parent (cell);
  (* func) (cell, data);

  /* check that cell has not been deallocated by @func */
  g_assert (parent == NULL || parent->children != NULL);

  if (!FTT_CELL_IS_LEAF (cell)) {
    FttOct * children = cell->children;
    guint n;

    for (n = 0; n < FTT_CELLS; n++) {
      FttCell * c = &(children->cell[n]);
      if (!FTT_CELL_IS_DESTROYED (c))
	cell_traverse_pre_order_all (c, max_depth, func, data);
    }
  }
}


/* 
 * Traverse the tree into given level post post-order
 * @Fttcell cell : root 
 * @ gint max_depth: given level
 * @ FttCellTraverseFunc func: user define function to pass
 * @  gpointer data: pointer pointer to data
 */
static void cell_traverse_post_order_all (FttCell * cell,
					  gint max_depth,
					  FttCellTraverseFunc func,
					  gpointer data)
{
  if (max_depth >= 0 && ftt_cell_level (cell) > max_depth)
    return;

  if (!FTT_CELL_IS_LEAF (cell)) {
    FttOct * children = cell->children;
    guint n;

    for (n = 0; n < FTT_CELLS; n++) {
      FttCell * c = &(children->cell[n]);

      if (!FTT_CELL_IS_DESTROYED (c))
	cell_traverse_post_order_all (c, max_depth, func, data);
    }
  }

  (* func) (cell, data);

}

/* 
 * Traverse the tree into given level 
 * @Fttcell cell : root 
 * @ FttTraverseType order : preoder or post other
 * @ gint max_depth: given level
 * @ FttCellTraverseFunc func: user define function to pass
 * @  gpointer data: pointer pointer to data
 */
void ftt_cell_traverse (FttCell * root,
			FttTraverseType order,
			FttTraverseFlags flags,
			gint max_depth,
			FttCellTraverseFunc func,
			gpointer data)
{
  g_return_if_fail (root != NULL);
  g_return_if_fail (func != NULL);

  if (max_depth >= 0 && ftt_cell_level (root) > max_depth)
    return;

  if (flags == FTT_TRAVERSE_ALL) {
    if (order == FTT_PRE_ORDER)
      cell_traverse_pre_order_all (root, max_depth, func, data);
    else
      cell_traverse_post_order_all (root, max_depth, func, data);
  }
   else if ((flags & FTT_TRAVERSE_LEVEL) != 0) {
    if ((flags & FTT_TRAVERSE_LEAFS) != 0)
      cell_traverse_level_leafs (root, max_depth, func, data);
    else if ((flags & FTT_TRAVERSE_NON_LEAFS) != 0)
      cell_traverse_level_non_leafs (root, max_depth, func, data);
    else
      cell_traverse_level (root, max_depth, func, data);
  }
  else if ((flags & FTT_TRAVERSE_LEAFS) != 0)
    cell_traverse_leafs (root, max_depth, func, data);
  else {
    g_return_if_fail ((flags & FTT_TRAVERSE_NON_LEAFS) != 0);

    if (order == FTT_PRE_ORDER)
      cell_traverse_pre_order_nonleafs (root, max_depth, func, data);
    else
      cell_traverse_post_order_nonleafs (root, max_depth, func, data);
  }  

}

gint ftt_opposite_direction[FTT_NEIGHBORS] =
#if      FTT_2D
  {1, 0, 3, 2};
#else  /* FTT_3D */
  {1, 0, 3, 2, 5, 4};
#endif /* FTT_3D */


/* 
 * Traverse and Destroy an octree by destroy all children
 * @FttOct oct: Octree
 * @ FttCellCleanupFunc cleanup: user define function passed to
 * @gpointer data: poiter to data passed to
 */
static void oct_destroy (FttOct * oct,
			 FttCellCleanupFunc cleanup,
			 gpointer data)
{
  guint n;

  g_return_if_fail (oct != NULL);
  g_return_if_fail (oct->parent->children == oct);

  oct->parent->children = NULL;
  for (n = 0; n < FTT_CELLS; n++)
    ftt_cell_destroy (&(oct->cell[n]), cleanup, data);
  g_free (oct);
}


/* 
 * Destroy a cell, will destroy all of it children if it has
 * @FttCell cell: cell want to delete
 * @ FttCellCleanupFunc cleanup: user define function passed to
 * @gpointer data: poiter to data passed to
 */
void ftt_cell_destroy (FttCell * cell,
		       FttCellCleanupFunc cleanup,
		       gpointer data)
{
  FttCellNeighbors neighbor;
  guint i, level;

  g_return_if_fail (cell != NULL);

	if (cell->deleted != 1){
		//printf("CELL NOT DELETED \n");
    	return;
	} 
  if (FTT_CELL_IS_DESTROYED (cell))
    return;

  ftt_cell_neighbors (cell, &neighbor);
  level = ftt_cell_level (cell);

  if (cleanup)
    (* cleanup) (cell, data);
  cell->flags |= FTT_FLAG_DESTROYED;

  /* destroy children */
  if (!FTT_CELL_IS_LEAF (cell)) {
    oct_destroy (cell->children, cleanup, data);
    cell->children = NULL;
  }

  /* update relationships for neighbors */
  for (i = 0; i < FTT_NEIGHBORS; i++)
    if (neighbor.c[i] && ftt_cell_level (neighbor.c[i]) == level) {
      FttDirection od = FTT_OPPOSITE_DIRECTION (i);

      if (FTT_CELL_IS_ROOT (neighbor.c[i])) {
	FttCell * opneighbor = FTT_ROOT_CELL (neighbor.c[i])->neighbors.c[od];

	g_assert (opneighbor == cell);
	FTT_ROOT_CELL (neighbor.c[i])->neighbors.c[od] = NULL;
      }
      if (!FTT_CELL_IS_LEAF (neighbor.c[i]))
	neighbor.c[i]->children->neighbors.c[od] = NULL;
    }
  
  if (FTT_CELL_IS_ROOT (cell))
    g_free (cell);
  else if (!FTT_CELL_IS_LEAF (cell->parent->parent)) {
    /* if parent Oct is not already destroyed and empty destroy it */
    FttOct * parent = cell->parent;
    gboolean empty = TRUE;

    for (i = 0; i < FTT_CELLS && empty; i++)
      if (!FTT_CELL_IS_DESTROYED (&(parent->cell[i])))
	empty = FALSE;
    if (empty)
      oct_destroy (parent, NULL, NULL);
  }
}


/**
 * ftt_cell_coarsen:
 * @root: a #FttCell root of a cell tree to coarsen.
 * @coarsen: a #FttCellCoarsenFunc.
 * @coarsen_data: user data to pass to @coarsen.
 * @cleanup: a #FttCellCleanupFunc to call before destroying a cell or %NULL.
 * @cleanup_data: user data to pass to @cleanup.
 *
 * Coarsens the cell tree defined by @root according to @coarsen.
 *
 * Returns: %TRUE if @root has been coarsened (i.e. @root is now a
 * leaf cell), %FALSE otherwise.
 */
gboolean ftt_cell_coarsen (FttCell * root,
			   FttCellCoarsenFunc coarsen,
			   gpointer coarsen_data,
			   FttCellCleanupFunc cleanup,
			   gpointer cleanup_data)
{
	
#ifdef MPI //MPI code
	//For each processors, need to work on specific "branches"
	if(ftt_cell_level (root) == deep){
		branch_count++;
	//branch number start for each rank
		if(rank!= size - 1){
			branch_number_start = branch_each_processor*(rank) + 1;
			branch_number_end = branch_each_processor*(rank + 1);
		}else{
			branch_number_start = branch_each_processor*(size -1) + 1;
			branch_number_end = branches_on_deep;
		}
		if((branch_number_start <= branch_count) && (branch_count <= branch_number_end)){
			;; // continue working on these branches
		}else{
			// Do nothing on those branches, just return
			return FALSE;
		}
	}
#endif //end MPI code


	guint i;
	gboolean coarsenable = TRUE;

	g_return_val_if_fail (root != NULL, FALSE);
	g_return_val_if_fail (coarsen != NULL, FALSE);

	if (FTT_CELL_IS_LEAF (root)){
		root->deleted = 1;
		return (* coarsen) (root, coarsen_data);
	}

	for (i = 0; i < FTT_CELLS; i++)
		if (!FTT_CELL_IS_DESTROYED (&(root->children->cell[i])))
	  		coarsenable &= ftt_cell_coarsen (&(root->children->cell[i]), coarsen, coarsen_data,cleanup, cleanup_data);
	if (!coarsenable || !(* coarsen) (root, coarsen_data)){
		return FALSE;
	}
{
    FttDirection d;
	guint  n;
    for (d = 0; d < FTT_NEIGHBORS; d++) {
      	FttCellChildren child;
      	n = ftt_cell_children_direction (root, d, &child);
      	for (i = 0; i < n; i++) {
			FttCell * neighbor;
			if (child.c[i] && (neighbor = ftt_cell_neighbor (child.c[i], d)) &&
	    !FTT_CELL_IS_LEAF (neighbor)) {
	 			 FttCellChildren child1;
	 			 guint j, k;
	  			 gboolean empty = TRUE;

	 			 k = ftt_cell_children_direction (neighbor, FTT_OPPOSITE_DIRECTION (d), &child1);
	 			 for (j = 0; j < k && empty; j++)
	   				 if (child1.c[j])
	     				 empty = FALSE;
	  			if (!empty && !ftt_cell_coarsen (neighbor, coarsen, coarsen_data, cleanup, cleanup_data))
	   				 return FALSE;
	 			 if (!FTT_CELL_IS_LEAF (neighbor))
	   			 neighbor->children->neighbors.c[FTT_OPPOSITE_DIRECTION (d)] = NULL;
			}
      }
    }
}
#ifdef NVRAM
	if (cleanup){
	    for (i = 0; i < FTT_CELLS; i++)
	    	if (!FTT_CELL_IS_DESTROYED (&(root->children->cell[i])))
			(* cleanup) (&(root->children->cell[i]), cleanup_data);
	}
	if(root->nvramflag == 0 ){	 //if cell in dram
			dramcount -= 8;		
	}	
#else
	if (cleanup){
	    for (i = 0; i < FTT_CELLS; i++)
	    	if (!FTT_CELL_IS_DESTROYED (&(root->children->cell[i])))
			(* cleanup) (&(root->children->cell[i]), cleanup_data);
	}	
#endif

	g_free (root->children);
	root->children = NULL;
	return TRUE;
}


/* 
 * Refine funtion to refine the tree
 * @root: root node of tree
 * @refine: user define function - refine predicate
 * @refine_data: data want to refine to be
 * @init: user define function to init cell
 * @init_data: initial data pass to function
 */
void ftt_cell_refine (FttCell * root,
		      FttCellRefineFunc refine,
		      gpointer refine_data,
		      FttCellInitFunc init,
		      gpointer init_data)
{
  if(root->data!=NULL){
  	init_data = root->data;	
  }
  guint n;
  FttOct * oct;
  g_return_if_fail (root != NULL);
  g_return_if_fail (refine != NULL);

  if(ftt_cell_level (root) >= MAX_LEVEL) return; 
  if (FTT_CELL_IS_LEAF (root) && !(* refine) (root, refine_data))
    return;
  	
  if (FTT_CELL_IS_LEAF (root)){
	    oct_new_refine (root, TRUE, init, init_data, 1);
	}
	

  g_assert (!FTT_CELL_IS_DESTROYED (root));
  oct = root->children;
  for (n = 0; n < FTT_CELLS; n++)
    if (!FTT_CELL_IS_DESTROYED (&(oct->cell[n]))){
      ftt_cell_refine (&(oct->cell[n]), refine, refine_data, init, init_data);
	}
}



/* 
 * Refine funtion to refine the tree
 * @root: root node of tree
 * @refine: user define function - refine predicate
 * @refine_data: data want to refine to be
 * @init: user define function to init cell
 * @init_data: initial data pass to function
 */
void ftt_cell_refine_value (FttCell * root,
		      FttCellRefineFunc refine,
		      gpointer refine_data,
		      FttCellInitFunc init,
		      gpointer init_data)
{
  if(root->data!=NULL){
  	init_data = root->data;	
  }
  guint n;
  FttOct * oct;
  g_return_if_fail (root != NULL);
  g_return_if_fail (refine != NULL);

  if(ftt_cell_level (root) >= MAX_LEVEL ) return; 
  if (FTT_CELL_IS_LEAF (root) && !(* refine) (root, refine_data))
    return;
  	
  if (FTT_CELL_IS_LEAF (root)){
	    oct_new_refine (root, TRUE, init, init_data, 1);
	}
	

  g_assert (!FTT_CELL_IS_DESTROYED (root));
  oct = root->children;
  for (n = 0; n < FTT_CELLS; n++)
    if (!FTT_CELL_IS_DESTROYED (&(oct->cell[n]))){
      ftt_cell_refine (&(oct->cell[n]), refine, refine_data, init, init_data);
	}
}



/*
 * partition the tree to 2 parts, 1 in dram and 1 part in nvram
 * @root: root of a tree
 * @part: which branch of a tree that we want to store in dram
*/
void pm_partition(FttCell * root, guint part){
	g_return_if_fail (root != NULL);
	guint n;

	if(FTT_CELL_IS_LEAF(root) ){
		root->nvramflag = 0;
		return;
	}		
	
	FttOct * oct;
	oct = root->children;
		for(n = 0; n < FTT_CELLS; n++){			
			if(n == part){
				oct->cell[n].nvramflag = 0;
				pm_partition(&(oct->cell[n]), -1);
				break;
			}else if(part == -1){
				oct->cell[n].nvramflag = 0;
				pm_partition(&(oct->cell[n]), -1);
			}
		}

}

/*
 * Merge the trees in dram into tree in nvram
 * @root: root of a tree
 * @part: which branch of a tree that we want to store in dram
*/

void pm_merge(FttCell * root, guint part){
	g_return_if_fail (root != NULL);
	guint n;
	if(FTT_CELL_IS_LEAF(root) ){
		root->nvramflag = 1;
		return;
	}		
	
	FttOct * oct;
	oct = root->children;
		for(n = 0; n < FTT_CELLS; n++){			
			if(n == part){
				oct->cell[n].nvramflag = 1;
				pm_merge(&(oct->cell[n]), -1);
				break;
			}else if(part == -1){
				oct->cell[n].nvramflag = 1;
				pm_merge(&(oct->cell[n]), -1);
			}
		}
}


/*
 * Merge the trees in dram into tree in nvram for certain part, not all the subtree but part of it
 * @root: root of a tree
 * @part: which branch of a tree that we want to store in dram
*/

void pm_partial_merge(FttCell * root, guint part){
	g_return_if_fail (root != NULL);
	guint n;
	if(dramcount < RAMBOUND/3) return;

	if(FTT_CELL_IS_LEAF(root)){
		if(root->nvramflag != 1){
			root->nvramflag = 1;
			dramcount--;
		}
		return;
	}		
	
	FttOct * oct;
	oct = root->children;
		for(n = 0; n < FTT_CELLS; n++){		
			if(dramcount < RAMBOUND/2) break;	
			if(n == part){
				if(oct->cell[n].nvramflag != 1){
					oct->cell[n].nvramflag = 1;
					dramcount--;
				}
				pm_partial_merge(&(oct->cell[n]), -1);
				break;
			}else if(part == -1){
				if(oct->cell[n].nvramflag != 1){
					oct->cell[n].nvramflag = 1;
					dramcount--;
				}
				pm_partial_merge(&(oct->cell[n]), -1);
			}
		}
}


/*
 * Traverse and Remark all the cell to nvramflag -> save to nvram
 * @root: root of a tree
*/
void save_nvram(FttCell * root){
	g_return_if_fail (root != NULL);
	guint n;
	root->nvramflag  = 1;
	root->deleted = 0;
	if(FTT_CELL_IS_LEAF(root) ){
		return;
	}		
	
	FttOct * oct;
	oct = root->children;
	for(n = 0; n < FTT_CELLS; n++){			
		save_nvram(&(oct->cell[n]));
	}
		
}


/*
 * Persistent - swap address of v1 and v0 trees
 * @v0: root of a tree V0
 * @v1: root of pm-octree v1 
*/
void pm_persistent(FttCell ** v0, FttCell ** v1){
	clock_t begin = clock();
	FttCell * temp;
	gpointer data;
	data = (*v1)->data;
	FttCellInitFunc init;
	init = addFunc;
	temp = ftt_cell_new(init, data);
	temp->data = NULL;
	temp = *v0;
	*v0 = *v1;
	*v1 = temp;
//remark cells that now in NVRAM 
	save_nvram(*v0);
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	if(DEBUG) printf("Time for persistent octree: %lf seconds \n", time_spent);

}

/*
 * Refine function to refine the tree in pmoctree - locational base
 * @v0: root of a tree V0
 * @v1: root of pm-octree v1 
 * @refine: refine predicate
 * @init: user define function to add data to cell
 * @init_data: data
 * @nvram: flag to know if operation on nvram or dram
*/
int num = 0;
void ftt_cell_refine_pm (FttCell * v0,
	FttCellRefineFunc refine,
	gpointer refine_data,
	FttCellInitFunc init,
	gpointer init_data,
  	FttCell * v1, guint nvram, FttCell * mainroot){
	
	gboolean check_neighbor = TRUE;

#ifdef MPI //MPI code
	check_neighbor = FALSE;
	//For each processors, need to work on specific "branches"
	if(ftt_cell_level (v0) == deep){
		branch_count++;
	//branch number start for each rank
		if(rank!= size - 1){
			branch_number_start = branch_each_processor*(rank) + 1;
			branch_number_end = branch_each_processor*(rank + 1);
		}else{
			branch_number_start = branch_each_processor*(size -1) + 1;
			branch_number_end = branches_on_deep;
		}
		if((branch_number_start <= branch_count) && (branch_count <= branch_number_end)){
			;;// Continue working on
		}else{
			//
			return;
		}
	}
#endif //end MPI code


	if(!init_data){	
		if(v0->data!=NULL){ init_data = v0->data;}
	}
	//If number of octant in dram larger than the bound then merger and continue
	if(dramcount >= RAMBOUND){
		num++;
 		pm_partial_merge(mainroot, 7);
	}
	guint n, m, k;
	FttOct * oct, * oct_pm;

	g_return_if_fail (v0 != NULL);
	g_return_if_fail (v1 != NULL);
	g_return_if_fail (refine != NULL);
	
	v0->deleted = 1;
	if(ftt_cell_level (v0) >= MAX_LEVEL) return; 
	if (FTT_CELL_IS_LEAF (v0) && !(* refine) (v0, refine_data)){
		return;
	}

	if (FTT_CELL_IS_LEAF (v0)){
		if(v0->nvramflag == 0 ){	 //if cell in dram
			v1->nvramflag = 0;	
			if(!v1->children)
				oct_new_refine(v1, check_neighbor, init, init_data, 0);
			oct_pm = v1->children;
			for (n = 0; n < FTT_CELLS ; n++){
				ftt_cell_refine_pm (&(oct_pm->cell[n]), refine, refine_data, init, init_data, &(oct_pm->cell[n]), 0, mainroot);
			}
		}else{ //cell in nvram
			v1->nvramflag = 1;			
			if(!v1->children)
				oct_new_refine(v1, check_neighbor, init, init_data, 1);
			oct_pm = v1->children;
			for (n = 0; n < FTT_CELLS ; n++){
				//if nvram then set flag
				ftt_cell_refine_pm (&(oct_pm->cell[n]), refine, refine_data, init, init_data, &(oct_pm->cell[n]), 1, mainroot);
			}

		}
		return;
	}

	g_assert (!FTT_CELL_IS_DESTROYED (v0));
	g_assert (!FTT_CELL_IS_DESTROYED (v1));
	// create cell and append to pm-octree
	oct = v0->children;
	if(v1->children == NULL){
		gpointer olddata;
		olddata = v0->data;
		if(v0->nvramflag == 0){
			oct_new (v1, TRUE, init, olddata, 0);
		}else{
			oct_new (v1, TRUE, init, olddata, 1);
		}

		oct_pm = v1->children;		
		for(k = 0; k < FTT_CELLS;k++){
			FttCell * oldCell = &(oct->cell[k]);
			if(oldCell->data){
				init_data = oldCell->data;
				FttCell * c = &(oct_pm->cell[k]);
				(* init) (c, init_data);
			}
			oct_pm->cell[k].nvramflag = oct->cell[k].nvramflag;
		}
	}else{	
		oct_pm = v1->children;
	}

	for (m = 0; m < FTT_CELLS; m++){
		FttCell * oldCell = &(oct->cell[m]);
		if(oldCell->data){
			init_data = oldCell->data;
		}	
		ftt_cell_refine_pm (&(oct->cell[m]), refine, refine_data, init, init_data, &(oct_pm->cell[m]), 1, mainroot );
	}  

}


/*
 * Refine function to refine the tree in pmoctree - valued  base
 * @v0: root of a tree V0
 * @v1: root of pm-octree v1 
 * @refine: refine predicate
 * @init: user define function to add data to cell
 * @init_data: data
 * @nvram: flag to know if operation on nvram or dram
*/
void ftt_cell_refine_value_pm (FttCell * v0,
	FttCellRefineFunc refine,
	gpointer refine_data,
	FttCellInitFunc init,
	gpointer init_data,
  	FttCell * v1, guint nvram, FttCell * mainroot){
	g_return_if_fail (v0 != NULL);
	g_return_if_fail (v1 != NULL);
	g_return_if_fail (refine != NULL);	
	gboolean check_neighbor = TRUE;

#ifdef MPI //MPI code
	check_neighbor = FALSE;
	//For each processors, need to work on specific "branches"
	if(ftt_cell_level (v0) == deep){
		branch_count++;
	//branch number start for each rank
		if(rank!= size - 1){
			branch_number_start = branch_each_processor*(rank) + 1;
			branch_number_end = branch_each_processor*(rank + 1);
		}else{
			branch_number_start = branch_each_processor*(size -1) + 1;
			branch_number_end = branches_on_deep;
		}
		if((branch_number_start <= branch_count) && (branch_count <= branch_number_end)){
			;;//continue
		}else{
			// do nothing on those branch just return
			return;
		}
	}
#endif //end MPI code

	if(!init_data){	
		if(v0->data!=NULL){ init_data = v0->data;}
	}
	//If number of octant in dram larger than the bound then merger and continue
	if(dramcount >= RAMBOUND){
		num++;
 		pm_partial_merge(mainroot, 7);
	}

	guint n, m, k;
	FttOct * oct, * oct_pm;
	if(ftt_cell_level (v0) >= MAX_LEVEL) return; 
	if (FTT_CELL_IS_LEAF (v0) && !(* refine) (v0, refine_data)){
		return;
	}

	if (FTT_CELL_IS_LEAF (v0)){
		if(v0->nvramflag == 0){	 //if cell in dram
			if(!v1->children)
				oct_new_refine(v1, check_neighbor, init, init_data, 0);
			oct_pm = v1->children;
			for (n = 0; n < FTT_CELLS ; n++){
				ftt_cell_refine_value_pm (&(oct_pm->cell[n]), refine, refine_data, init, init_data, &(oct_pm->cell[n]), 0, mainroot );
			}
		}else{
			if(!v1->children)
				oct_new_refine(v1, check_neighbor, init, init_data, 1);
			oct_pm = v1->children;
			for (n = 0; n < FTT_CELLS ; n++){
				ftt_cell_refine_value_pm (&(oct_pm->cell[n]), refine, refine_data, init, init_data, &(oct_pm->cell[n]), 1, mainroot);
			}
		}
		return;
	}

	g_assert (!FTT_CELL_IS_DESTROYED (v0));
	g_assert (!FTT_CELL_IS_DESTROYED (v1));
	oct = v0->children;
	if(v1->children == NULL){
		gpointer olddata;
		olddata = v0->data;
		if(v0->nvramflag == 0){
			oct_new (v1, TRUE, init, olddata, 0);
		}else{
			oct_new (v1, TRUE, init, olddata, 1);
		}
		oct_pm = v1->children;		
		for(k = 0; k < FTT_CELLS;k++){
			FttCell * oldCell = &(oct->cell[k]);
			if(oldCell->data){
				init_data = oldCell->data;
				FttCell * c = &(oct_pm->cell[k]);
				(* init) (c, init_data);
			}
			oct_pm->cell[k].nvramflag = oct->cell[k].nvramflag;
		}
	}else{	
		oct_pm = v1->children;
	}

	for (m = 0; m < FTT_CELLS; m++){
		FttCell * oldCell = &(oct->cell[m]);
		if(oldCell->data){

			init_data = oldCell->data;
		}			
		ftt_cell_refine_value_pm (&(oct->cell[m]), refine, refine_data, init, init_data, &(oct_pm->cell[m]), 1 , mainroot);
	}  

}


/*
 * Oct_new to create a array of 8 children for a cell - initilly these children do not have data
 * @parent: a cell that we want to create its children
 * @check_neighbor: flag to know if we want to check and create its neighbors' children to maintain balance
 * @init: user define function to initialize data for cell
 * @data: data passed to 
 * @nvram: flag to know  cell in nvram or dram
*/
static void oct_new (FttCell * parent,
		     gboolean check_neighbors,
		     FttCellInitFunc init,
		     gpointer data, guint nvram)
{

  FttOct * oct;
  guint n;
  g_assert (parent != NULL);
  g_assert (parent->children == NULL);
		
	if(nvram){
		parent->nvramflag = 1;

	}else{
		parent->nvramflag = 0;
		 dramcount += 8;
	}	

  oct = g_malloc0 (sizeof (FttOct));
  oct->level = ftt_cell_level (parent);
  oct->parent = parent;

  ftt_cell_pos (parent, &(oct->pos));	
  ftt_cell_neighbors (parent, &(oct->neighbors));

  for (n = 0; n < FTT_CELLS; n++) {
    oct->cell[n].parent = oct;
    oct->cell[n].flags = n;
		//if nvram then set flag
	if(nvram){
		 oct->cell[n].nvramflag = 1;
	} else{
		oct->cell[n].nvramflag = 0;
	}

  }

  if (check_neighbors)
    for (n = 0; n < FTT_NEIGHBORS; n++) {
      FttCell * neighbor = oct->neighbors.c[n];
      
      if (neighbor && ftt_cell_level (neighbor) < oct->level && neighbor->children == NULL) {
		if(neighbor->data){
			data = neighbor->data;
		}
		oct_new (neighbor, check_neighbors, init, data, neighbor->nvramflag);
		oct->neighbors.c[n] = ftt_cell_neighbor (parent, n);
      }
    }

  g_assert (parent->children == NULL);
  parent->children = oct;
  
  if (init)
    (* init) (parent, data);
}



/*
 * Oct_new to create a array of 8 children for a cell - initilly these children will have data inherited from parent, except coordinate will be different
 * @parent: a cell that we want to create its children
 * @check_neighbor: flag to know if we want to check and create its neighbors' children to maintain balance
 * @init: user define function to initialize data for cell
 * @data: data passed to 
 * @nvram: flag to know  cell in nvram or dram
*/
static void oct_new_refine (FttCell * parent,
		     gboolean check_neighbors,
		     FttCellInitFunc init,
		     gpointer data, guint nvram)
{ 
 

  FttOct * oct;
  guint n;
  g_assert (parent != NULL);
  g_assert (parent->children == NULL);

	if(nvram){
		parent->nvramflag = 1;
	}else{
		parent->nvramflag = 0;
		dramcount += 8;
	}
  oct = g_malloc0 (sizeof (FttOct));
  oct->level = ftt_cell_level (parent);
  oct->parent = parent;

  ftt_cell_pos (parent, &(oct->pos));	
  ftt_cell_neighbors (parent, &(oct->neighbors));
  
  address_t addr;
  addr = *(address_t*) data;
  addr.type = 1;

  for (n = 0; n < FTT_CELLS; n++) {
    oct->cell[n].parent = oct;
    oct->cell[n].flags = n;
	(* init) (&oct->cell[n], &addr);
			//if nvram then set flag
	if(nvram){
		 oct->cell[n].nvramflag = 1;
	}else{
		oct->cell[n].nvramflag = 0;
	}
  }

  if (check_neighbors)
    for (n = 0; n < FTT_NEIGHBORS; n++) {
      FttCell * neighbor = oct->neighbors.c[n];
      if (neighbor && ftt_cell_level (neighbor) < oct->level && neighbor->children == NULL) {
		if(neighbor->data){
			data = neighbor->data;
		}
		oct_new_refine (neighbor, check_neighbors, init, data, neighbor->nvramflag);
		oct->neighbors.c[n] = ftt_cell_neighbor (parent, n);
      }
    }

  g_assert (parent->children == NULL);
  parent->children = oct;

  	addr = *(address_t*) data;
  	addr.type = 0;
  	if (init)
    (* init) (parent, &addr);
  
}

/*
 * addFunc: user defined function to pass to other function to initialize data for a cell
 * @cell: cell want to initialize data
 * @data: data poited by a poiter
*/
void addFunc(FttCell * cell, gpointer data){
		address_t pl2;
		pl2 = *(address_t*)data;
		int x = pl2.x;
		int y = pl2.y;
		int z = pl2.z;
		int val = pl2.val;
		char tag = pl2.tag;
		int type = pl2.type;
		address_t * addr;
 		addr = g_malloc0 (sizeof (address_t));
		addr->val = val;
		addr->x = x;
		addr->y = y;
		addr->z= z;
		addr->tag = tag;
		addr->type = type;
		cell->data = addr;
}

/*
 * ClearFunc: user defined function to pass to other function to free data for a cell
 * @cell: cell want to clear data
 * @data: data poited by a poiter
*/
void clearFunc(FttCell * cell, gpointer data){
  	g_free(cell->data);
	cell->data = NULL;
	return;
}

/*
 * Traverse Func: user defined function to pass to other function to trarverse
 * @cell: cell want to start traverse 
 * @data: data poited by a poiter
*/
void traverseFunc(FttCell * cell, gpointer data){
	return;
}


/*
 * refine to given level
 * refineFunc: user defined function to pass to other function to refine a tree
 * @cell:  rootcell of tree want to refine
 * @data: data poited by a poiter
*/
static gboolean refineFunc (FttCell * cell, gpointer refine)
{
		
	gint i;	
	i = GPOINTER_TO_INT(refine);
  return (ftt_cell_level (cell) < i);
}



/*
 * refine cell that satisfied valued-base predicate
 * refineFunc: user defined function to pass to other function to refine a tree
 * @cell:  rootcell of tree want to refine
 * @data: data poited by a poiter
*/
static gboolean refineValueFunc (FttCell * cell, gpointer refine)
{
		
	gint i;	
	i = GPOINTER_TO_INT(refine);
	if(refine_value_pred(cell, i) == 1){ 
		return TRUE;}
	return FALSE;
}


/*
 * refine cell that satisfied locational-base predicate
 * refineFunc: user defined function to pass to other function to refine a tree
 * @cell:  rootcell of tree want to refine
 * @data: data poited by a poiter
 * Under what condtion the cell will be refine (now it set to certain level e.g refine base on mesh location
*/

static gboolean refineLocationFunc (FttCell * cell, gpointer refine)
{
		
	gint i;	
	i = GPOINTER_TO_INT(refine);
	if(refine_pred(cell, i) == 1){ 
		return TRUE;}
	return FALSE;
}


/*
 * refine cell that satisfied locational-base predicate - diferrent mesh
 * refineFunc: user defined function to pass to other function to refine a tree
 * @cell:  rootcell of tree want to refine
 * @data: data poited by a poiter
 * Under what condtion the cell will be refine (now it set to certain level e.g refine base on mesh location
*/
static gboolean refineLocationFunc1 (FttCell * cell, gpointer refine)
{
		
	gint i;	
	i = GPOINTER_TO_INT(refine);
	if(refine_pred1(cell, i) == 1){ 
		return TRUE;}
	return FALSE;
}


/* z- range of the mesh to see if cell need to be refine */
gboolean z_inside(double z){
	double input_z [2] = {-20 , 30};
	//return if num1 <= z <= num2
	return ((z >= input_z[0]) && (z <= input_z[1]));
}

/* z- range of the mesh to see if cell need to be refine */
gboolean z_inside1(double z){
	double input_z [2] = {-200 , 200};
	//return if num1 <= z <= num2
	return ((z >= input_z[0]) && (z <= input_z[1]));
}

/*get new x0, y0 and R to of the mesh (or disk  in 3D),
initial x = 128, y = -10 , z = [-50,50] and R = 138 */
double * get_mesh(double theta){
	double * mesh = malloc(3 * sizeof(double));
// x0' = x + R sin(theta)
	mesh[0] = (double)(128*cos(theta) - (-10)*sin(theta)) ; 
// y0' = x + R cos(theta)
	mesh [1] = (double)(128*sin(theta) +(-10)*cos(theta)) ;
//R
	mesh[2] = 150; 	

	return mesh;

}

/*get a, b, c for x2/a2 + y2/b2 - z2/c2 = R2 */
double * get_mesh1(){
	double * mesh = malloc(3 * sizeof(double));
//a, b, c for the mesh x2/a2 + y2/b2 - z2/c2 = 1
	mesh[0] = 80 ; 
	mesh [1] = 40;
	mesh[2] = 150; 	
	return mesh;

}

/*
 * Return if point is inside the mesh or not
 * @point: array of x,y,z of a cell
 * @mesh: mesh information eg: x^2 + y^2 = R^2
 */
gboolean point_inside_mesh(double point[3], double * mesh){
    double x, y, z;
    double x0, y0, R;
    gboolean inside;
    //mesh
    x0 = mesh[0];
    y0 = mesh[1];
    R = mesh[2];
    //point to check
    x = point[0];
    y = point[1];
    z = point [2];
    //return true if point is inside mesh, otherwise return false
    inside = (((x - x0)*(x-x0) + (y - y0)*(y - y0)) < R*R)  && z_inside(z);
    return (inside);
 
}

/*
 * Return if point is inside the mesh or not
 * @point: array of x,y,z of a cell
 * @mesh: mesh information eg: x^2 + y^2 = R^2
 */
gboolean point_inside_mesh1(double point[3], double * mesh){
	double x, y, z;
	double a, b, c;
	gboolean inside;
	//mesh
	a = mesh[0];
	b = mesh[1];
	c = mesh[2];
	//point to check
	x = point[0];
	y = point[1];
	z = point [2];
	//return true if point is inside mesh, otherwise return false
	inside = ((x*x/a*a) + (y*y/b*b) - (z*z/c*c) <= 150)  && z_inside1(z);
	return (inside);

}

/* 
 * helper funct to see if the cell is in the mesh - by compare coordinates of all corners of cell with the function of the mesh 
 * cell: cell want to check
 * theta: degree of mesh rotate
 */
gboolean inside_mesh(FttCell* cell, int theta){
	double  p1[3], p2[3], p3[3], p4[3], p5[3], p6[3], p7[3], p8[3];
	double size = MAX_SIZE;
	double inc = 0;
	guint flag;
	double x, y, z;
	int level;
	flag = FTT_CELL_ID (cell);
	level = (int) cell->parent->level + 1;
		//printf("level = %d \n", level);
	while(level >= 0){
		size /= 2;
		level--;
	}
	inc = size;
	x = cell->parent->pos.x + coords[flag][0]*size;
	y = cell->parent->pos.y + coords[flag][1]*size;
	z = cell->parent->pos.z + coords[flag][2]*size;

	//mesh 
	double * mesh ;
	double theta_;
	theta_ = (double) (theta*PI/180); //convert to radian
	mesh = get_mesh(theta_);
	//point - x, y, z

	p1[0] = x - inc;
	p1[1] = y + inc;
	p1[2] = z + inc;

	p2[0] = x + inc;
	p2[1] = y + inc;
	p2[2] = z + inc;
	
	p3[0] = x + inc;
	p3[1] = y + inc;
	p3[2] = z - inc;
	
	p4[0] = x - inc;
	p4[1] = y + inc;
	p4[2] = z - inc;

	p5[0] = x - inc;
	p5[1] = y - inc;
	p5[2] = z + inc;

	p6[0] = x + inc;
	p6[1] = y - inc;
	p6[2] = z + inc;

	p7[0] = x + inc;
	p7[1] = y - inc;
	p7[2] = z - inc;

	p8[0] = x - inc;
	p8[1] = y - inc;
	p8[2] = z - inc;

	//case 1: all points inside the mesh we wont refine

	if(point_inside_mesh(p1, mesh) && point_inside_mesh(p2, mesh) &&
		 point_inside_mesh(p3, mesh) && point_inside_mesh(p4, mesh) &&
		 point_inside_mesh(p5, mesh)&& point_inside_mesh(p6, mesh) && 
		 point_inside_mesh(p7, mesh) && point_inside_mesh(p8, mesh)) 	{
		free(mesh);
			//printf("cell not need to be refined \n"); 
		return FALSE;
	}

	//case 2: all points outside mesh, wont refine	
	if(!point_inside_mesh(p1, mesh) && !point_inside_mesh(p2, mesh) &&
		 !point_inside_mesh(p3, mesh) && !point_inside_mesh(p4, mesh) &&
		 !point_inside_mesh(p5, mesh) && !point_inside_mesh(p6, mesh) && 
		 !point_inside_mesh(p7, mesh) && !point_inside_mesh(p8, mesh)){
			//printf("cell not need to be refined \n"); 
	 	free(mesh);
		return FALSE;
	}	
		free(mesh);

	return TRUE;
}


/* helper funct to see if the cell is in the mesh - by compare coordinates of all corners of cell with the function of the mesh */
gboolean inside_mesh1(FttCell* cell, int theta){
	double  p1[3], p2[3], p3[3], p4[3], p5[3], p6[3], p7[3], p8[3];
	double size = MAX_SIZE;
	double inc = 0;
	guint flag;
	double x, y, z;
	int level;
	flag = FTT_CELL_ID (cell);
	level = (int) cell->parent->level + 1;
		//printf("level = %d \n", level);
	while(level >= 0){
		size /= 2;
		level--;
	}
	inc = size;
	x = cell->parent->pos.x + coords[flag][0]*size;
	y = cell->parent->pos.y + coords[flag][1]*size;
	z = cell->parent->pos.z + coords[flag][2]*size;

	//mesh 
	double * mesh ;
	mesh = get_mesh1();
	//point - x, y, z

	p1[0] = x - inc;
	p1[1] = y + inc;
	p1[2] = z + inc;

	p2[0] = x + inc;
	p2[1] = y + inc;
	p2[2] = z + inc;
	
	p3[0] = x + inc;
	p3[1] = y + inc;
	p3[2] = z - inc;
	
	p4[0] = x - inc;
	p4[1] = y + inc;
	p4[2] = z - inc;

	p5[0] = x - inc;
	p5[1] = y - inc;
	p5[2] = z + inc;

	p6[0] = x + inc;
	p6[1] = y - inc;
	p6[2] = z + inc;

	p7[0] = x + inc;
	p7[1] = y - inc;
	p7[2] = z - inc;

	p8[0] = x - inc;
	p8[1] = y - inc;
	p8[2] = z - inc;

	//case 1: all points inside the mesh we wont refine

	if(point_inside_mesh1(p1, mesh) && point_inside_mesh1(p2, mesh) &&
		 point_inside_mesh1(p3, mesh) && point_inside_mesh1(p4, mesh) &&
		 point_inside_mesh1(p5, mesh)&& point_inside_mesh1(p6, mesh) && 
		 point_inside_mesh1(p7, mesh) && point_inside_mesh1(p8, mesh)) 	{
		free(mesh);
			//printf("cell not need to be refined \n"); 
		return FALSE;
	}

	//case 2: all points outside mesh, wont refine	
	if(!point_inside_mesh1(p1, mesh) && !point_inside_mesh1(p2, mesh) &&
		 !point_inside_mesh1(p3, mesh) && !point_inside_mesh1(p4, mesh) &&
		 !point_inside_mesh1(p5, mesh) && !point_inside_mesh1(p6, mesh) && 
		 !point_inside_mesh1(p7, mesh) && !point_inside_mesh1(p8, mesh)){
			//printf("cell not need to be refined \n"); 
	 	free(mesh);
		return FALSE;
	}	
		free(mesh);

	return TRUE;
}


/* 
 * predicate define a octant should be modified or not
 * cell: given cell
 * theta: degree or value that a mesh will change
 */
int refine_pred(FttCell* cell, int theta)
{
	gboolean in;
	in = inside_mesh(cell, theta);
	if(in)

		return 1;
    else 
		return 0;
}

/* predicate define a octant should be modified or not */
int refine_pred1(FttCell* cell, int theta)
{
	gboolean in;
	in = inside_mesh1(cell, theta);
	if(in)

		return 1;
    else 
		return 0;
}


/* predicate define a octant should be modified or not */
int refine_value_pred(FttCell* cell, int value)
{
	char val = value;
	if(value == val){
		return 1;
	}else{
		return 0;
	}
}

/* predicate to check if a cell should be coarsen */
static gboolean coarsenFunc(FttCell* cell, gpointer theta)
{
	gboolean in;
	int angle = GPOINTER_TO_INT(theta);
	in = inside_mesh(cell, angle);
	if(in){
		coarsencount++;
		return TRUE;
	}else{ 
		return FALSE;
	}
}

/* testing  predicate to check if a cell should be coarsen */
static gboolean coarsenFunc1(FttCell* cell, gpointer level)
{
	int lev = GPOINTER_TO_INT(level);	
	if(ftt_cell_level (cell) >= lev){
		coarsencount++;
		return TRUE;
	}else{ 
		return FALSE;
	}
}

/*
 * Initialize a root cell
*/

FttCell * ftt_cell_new (FttCellInitFunc init,
			gpointer data)
{
  FttCell * cell;

  cell = g_malloc0 (sizeof (FttRootCell));
  if (init)
    (* init) (cell, data);

  return cell;
}

/*
 * Refine a single cell
 * @cell: given cell to refine
 * @init: user define funct to inilitalize data
 * @init_data: passing data
 * @nvram: flag to see if in nvram or dram
*/

void ftt_cell_refine_single (FttCell * cell,
			     FttCellInitFunc init,
			     gpointer init_data, guint nvram)
{
  g_return_if_fail (cell != NULL);
  g_return_if_fail (FTT_CELL_IS_LEAF (cell));

  oct_new (cell, TRUE, init, init_data, nvram);
}

/* Helper function to print the tree
 * @root: root of tree
 * @order: pre or post order
 */
void print_oct_tree(FttCell * root, FttTraverseType order){
	if(order == FTT_PRE_ORDER){		
		if(DEBUG) printf("PRINT TREE PRE_ODER \n");
		print_pre_order(root);
	}else if (order == FTT_POST_ORDER){
		if(DEBUG) printf("PRINT TREE POST_ODER \n");
		print_post_order(root);
	}
}


/* Insert function for pm_octree
 * @FttCell v0:  Rootcell for time 0 tree
 * @FttCell v1: Rootcell for time 1 tree
 * @init: initialize function to add data to cell
 * @init_data: passing data to add to a cell
 * @check_neighbor: check balance to refine nieghbors of a cell 
 */
void ftt_cell_insert_pm(FttCell * v0, FttCellInitFunc init, gpointer init_data, FttCell * v1, gboolean checkneighbor, guint nvram){
	address_t addr;
	addr = *(address_t*)init_data;
	guint n;

	if(FTT_CELL_IS_LEAF(v1)){ 
		if(v1->data == NULL) {
			//We're in empty leave node in v0 tree which is empty, will insert a new cell in v1 tree
			(* init) (v1, init_data);
			return;
		}else{
			//we're in a leave node that has data, we will create new octree in v1, insert into a proper cell
			gpointer olddata;
			olddata = v1->data;
		 	oct_new (v1, FALSE, init, olddata, nvram);	
			FttOct * children = v1->children;
			int octant = 0;
			if(addr.z < children->pos.z) octant |= 4;
			if(addr.y < children->pos.y) octant |= 2;
			if(addr.x >= children->pos.x)octant |= 1;				
			FttCell * c = &(children->cell[octant]);
			(* init) (c, init_data);
			return;	
		}
	//we're in interio node, recursively goes to child node untill right place
	}else{
		FttOct * children = v1->children;
		FttOct * children_pm;
		if(v1->children == NULL){
			gpointer olddata;
			olddata = v1->data;
		 	oct_new (v1, FALSE, init, olddata, nvram);
			children_pm = v1->children;
		}else{	
			children_pm = v1->children;
		}
		int octant = 0;
		if(addr.z < children->pos.z) octant |= 4;
		if(addr.y < children->pos.y) octant |= 2;
		if(addr.x >= children->pos.x) octant |= 1;		
		FttCell * c = &(children->cell[octant]);
		FttCell * c_pm = &(children_pm->cell[octant]);
		
		//update parent pointer
		for(n = 0; n < FTT_CELLS;n++){
			if(octant != n){
				children_pm->cell[n] = children->cell[n];
			}
		}
		if(v0->data){
			ftt_cell_insert_pm(c, init, init_data, c_pm, checkneighbor, nvram);
		}else{
			ftt_cell_insert_pm(c_pm, init, init_data, c_pm,checkneighbor, nvram);
		}

	}	
	return;
}


/* Update function for pm_octree
 * @FttCell v0:  Rootcell for time 0 tree
 * @FttCell v1: Rootcell for time 1 tree
 * @init: initialize function to add data to cell
 * @init_data: passing data to add to a cell
 * @check_neighbor: check balance to refine nieghbors of a cell 
 */
void ftt_cell_update_pm(FttCell * v0, FttCellInitFunc init, gpointer init_data, FttCell * v1, guint nvram){
	address_t addr;
	addr = *(address_t*)init_data;
	guint n;

	if(FTT_CELL_IS_LEAF(v0)){ 
	//if it is a leaf node we just need to update it data
			(* init) (v1, init_data);
			return;
	//we're in interio node, recursively goes to child node untill right place
	}else{
		FttOct * children = v0->children;
		FttOct * children_pm;
		if(v1->children == NULL){
			gpointer olddata;
			olddata = v0->data;
		 	oct_new (v1, FALSE, init, olddata, nvram);
			children_pm = v1->children;
		}else{	
			children_pm = v1->children;
		}
		int octant = 0;
		if(addr.z < children->pos.z) octant |= 4;
		if(addr.y < children->pos.y) octant |= 2;
		if(addr.x >= children->pos.x) octant |= 1;		
		FttCell * c = &(children->cell[octant]);
		FttCell * c_pm = &(children_pm->cell[octant]);
		//update parent pointer
		for(n = 0; n < FTT_CELLS;n++){
			if(octant != n){
				children_pm->cell[n] = children->cell[n];
			}
		}
		ftt_cell_update_pm(c, init, init_data, c_pm, 0);
	}	

	return;
}


/* Insert function for normal octree
 * @FttCell cell:  Rootcell of a tree
 * @init: initialize function to add data to cell
 * @init_data: passing data to add to a cell
 * @check_neighbor: check balance to refine nieghbors of a cell 
 */
void ftt_cell_insert(FttCell * cell, FttCellInitFunc init,
			     gpointer init_data, gboolean checkneighbor){
	address_t addr;
	addr = *(address_t*)init_data;
	//int d;
	if(FTT_CELL_IS_LEAF(cell)){ 
		if(cell->data == NULL) {
			(* init) (cell, init_data);
			//printf("EMPTY x-y-z - octant %lf  %lf  %lf   \n", addr.x, addr.y, addr.z);
			return;
		}
		if(cell->data){
			gpointer olddata;
			olddata = cell->data;
		 	oct_new (cell, checkneighbor, init, olddata, 1);	
			FttOct * children = cell->children;
			int octant = 0;
			if(addr.z < children->pos.z) octant |= 4;
			if(addr.y < children->pos.y) octant |= 2;
			if(addr.x >= children->pos.x) octant |= 1;				
			FttCell * c = &(children->cell[octant]);
			(* init) (c, init_data);
			return;
		}
	}else{
		
		FttOct * children = cell->children;
		int octant = 0;
		if(addr.z < children->pos.z) octant |= 4;
		if(addr.y < children->pos.y) octant |= 2;
		if(addr.x >= children->pos.x) octant |= 1;		
		FttCell * c = &(children->cell[octant]);
		ftt_cell_insert(c, init, init_data, checkneighbor);
	}	
}

/**
 * ftt_refine_corner:
 * @cell: a #FttCell.
 *
 * Returns: if any "corner" neighbors of @cell are more than one
 * level more refined
 */
void ftt_refine_corner (FttCell * cell, FttCellInitFunc init, gpointer init_data)
{
  FttCellNeighbors neighbor;
  guint i;

  g_return_if_fail (cell != NULL);

  ftt_cell_neighbors (cell, &neighbor);
  for (i = 0; i < FTT_NEIGHBORS; i++) {
    FttCell * n = neighbor.c[i];

    if (n && !FTT_CELL_IS_LEAF (n)) {
      FttCellChildren child;
      guint j, k;

      k = ftt_cell_children_direction (n, FTT_OPPOSITE_DIRECTION (i), &child);
      for (j = 0; j < k; j++) {
	FttCell * c = child.c[j];

	if (c) {
#if FTT_2D
	  static guint perpendicular[FTT_NEIGHBORS_2D][FTT_CELLS/2] =
	  {{2,3},
	   {2,3},
	   {1,0},
	   {1,0}};
	  FttCell * nc = ftt_cell_neighbor (c, perpendicular[i][j]);

	  if (nc && !FTT_CELL_IS_LEAF (nc)){
		init_data = cell->data;
		oct_new_refine (cell, TRUE, init, init_data, cell->nvramflag);
		balance = FALSE;
		return;	    
		//return TRUE;
		}
#else  /* FTT_3D */
	  static guint perpendicular[FTT_NEIGHBORS][FTT_CELLS/2][2] =
	  {{{4,2},{4,3},{5,2},{5,3}},
	   {{4,2},{4,3},{5,2},{5,3}},
	   {{4,1},{4,0},{5,1},{5,0}},
	   {{4,1},{4,0},{5,1},{5,0}},
	   {{2,1},{2,0},{3,1},{3,0}},
	   {{2,1},{2,0},{3,1},{3,0}}};
	  FttCell * nc0, * nc1;

	  nc0 = ftt_cell_neighbor (c, perpendicular[i][j][0]);
	  if (nc0 && !FTT_CELL_IS_LEAF (nc0)){
		if(cell->data)
			init_data = cell->data;
	#ifdef NVRAM
			if(cell->nvramflag == 0){	 //if cell in dram
				dramcount += 8;
			}
			balance = FALSE;
			oct_new_refine (cell, TRUE, init, init_data, cell->nvramflag);
			return;	
	#else
			balance = FALSE;
			oct_new_refine (cell, TRUE, init, init_data, cell->nvramflag);
			return;
	#endif    
		//return TRUE;
		}
	  nc1 = ftt_cell_neighbor (c, perpendicular[i][j][1]);
	  if (nc1 && !FTT_CELL_IS_LEAF (nc1)){
		
	#ifdef NVRAM
		if(cell->nvramflag == 0){	 //if cell in dram
				dramcount += 8;
		}
		balance = FALSE;
		if(cell->data)
			init_data = cell->data;
		oct_new_refine (cell, TRUE, init, init_data, 0);		
		return;	    
	#else
		balance = FALSE;
		if(cell->data)
			init_data = cell->data;
		oct_new_refine (cell, TRUE, init, init_data, 0);		
		return;	    
	#endif  
		//return TRUE;
		}
#endif /* FTT_3D */
	  if (!FTT_CELL_IS_LEAF (c)) {
	    FttCellChildren child;
	    guint j, k;

	    k = ftt_cell_children_direction (c, FTT_OPPOSITE_DIRECTION (i), &child);
	    for (j = 0; j < k; j++)
	      if (child.c[j]){


	#ifdef NVRAM
		if(cell->nvramflag == 0){	 //if cell in dram
				dramcount += 8;
		}
		balance = FALSE;
		if(cell->data)
			init_data = cell->data;
		oct_new_refine (cell, TRUE, init, init_data, cell->nvramflag);
		return;  
	#else
		balance = FALSE;
		if(cell->data)
			init_data = cell->data;
		oct_new_refine (cell, TRUE, init, init_data, cell->nvramflag);
		return; 
	#endif  		
		//return TRUE;
		}
	  }
	}
      }	
    }
  }
	return;
}

/* 
 * Naive garbage collector 
 * @root: root cell of a tree
 * Delete markerd cells in a tree
 */
void garbage_collector(FttCell * root){
	//printf("Deleted cell = %d \n",v0cell);
	clock_t begin = clock();	
	g_return_if_fail (root != NULL);
	gpointer data = NULL;
	FttCellCleanupFunc cleanup;
	cleanup = clearFunc;
	ftt_cell_destroy(root, cleanup, data);
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	if(DEBUG) printf("Time for garbage collector: %lf seconds \n", time_spent);
	return;
}

/* 
 * Check corner neighbor and refine to maintain balance of a tree 
 * @root: root cell of a tree
 * @init: initialize function to add data to cell
 * init_data: passing data
 */
void pm_balance(FttCell * root, FttCellInitFunc init, gpointer init_data){
	guint n;
	FttOct * oct /*, * parent*/;
	g_return_if_fail (root != NULL);
	//gboolean balance;
	if(ftt_cell_level (root) >= MAX_LEVEL )
		return; 
	if(FTT_CELL_IS_LEAF(root)){
		ftt_refine_corner (root,  init,  init_data);
		return;
	}
	oct = root->children;
	for (n = 0; n < FTT_CELLS; n++){
			pm_balance(&(oct->cell[n]), init, init_data);
	}
}



/* print test function */
void print_test(FttCell * rootcell, FttCell * pmrootcell){
	if(rootcell){	
		print_oct_tree(rootcell, FTT_PRE_ORDER);
		if(DEBUG) printf("The V0 tree has %d octants \n", count);
		count = 0;
	}else{
		print_oct_tree(pmrootcell, FTT_PRE_ORDER);
		if(DEBUG) printf("The V1 tree has %d octants \n", count);
		count = 0;
	}
}


/* 
 * Check corner neighbor and refine to maintain balance of a tree 
 * @root: root cell of a tree
 * @init: initialize function to add data to cell
 * init_data: passing data
 */
void nm_balance(FttCell * root, FttCellInitFunc init, gpointer init_data){
	guint n;
	FttOct * oct /*, * parent*/;
	g_return_if_fail (root != NULL);
	//gboolean balance;
	if(ftt_cell_level (root) >= MAX_LEVEL )
		return; 
	if(FTT_CELL_IS_LEAF(root)){
		ftt_refine_corner (root,  init,  init_data);
		return;
	}
	oct = root->children;
	for (n = 0; n < FTT_CELLS; n++){
			nm_balance(&(oct->cell[n]), init, init_data);
	}
}


/* balance test function */
void pm_balance_tree(FttCell * cell){
	FttCellInitFunc init;
	init = addFunc;
	gpointer init_data = cell->data;
	balance = TRUE;
	pm_balance(cell, init, init_data);
}

/* balance test function */
void balance_tree(FttCell * cell){
	FttCellInitFunc init;
	init = addFunc;
	gpointer init_data = cell->data;
	balance = TRUE;
	nm_balance(cell, init, init_data);
}

/* refine level-based pm_octree test */
void pm_refine_test(FttCell * rootcell, FttCell * pmrootcell){
	clock_t begin = clock();	
	gpointer ptr = NULL; 
	gpointer level = GINT_TO_POINTER (4); //refine to level 3
	FttCellRefineFunc refine;
	refine = refineFunc;
	FttCellInitFunc init;
	init = addFunc;
	ftt_cell_refine_pm (rootcell, refine, level, init, ptr, pmrootcell, 1, pmrootcell);
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	if(DEBUG) printf("Time for refine value-base[NORMAL]: %lf seconds \n", time_spent);
}

/* Coarsen level based test */
void coarsen_level_test(FttCell * rootcell){
	FttCellCleanupFunc cleanup;
	cleanup = clearFunc;
	FttCellCoarsenFunc coarsen;
	coarsen = coarsenFunc1;
	gpointer t = GINT_TO_POINTER (0);
	gpointer t1 = GINT_TO_POINTER (0);
	gboolean b = ftt_cell_coarsen (rootcell, coarsen,  t , cleanup, t1);
	if(b);

}

/* Coarsen test */
void coarsen_test(FttCell * rootcell){
	clock_t begin = clock();	
	FttCellCleanupFunc cleanup;
	cleanup = clearFunc;
	FttCellCoarsenFunc coarsen;
	coarsen = coarsenFunc;
	gpointer t = GINT_TO_POINTER (0);
	gpointer t1 = GINT_TO_POINTER (0);
	gboolean b = ftt_cell_coarsen (rootcell, coarsen,  t , cleanup, t1);
	if(b);
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	if(DEBUG) printf("Time for coarsen mesh = %lf seconds \n", time_spent);

	//printf("root has been coarsen = %s \n", (b ? "TRUE" : "FALSE"));
	//printf("Cells coarsen count %d \n", coarsencount);
}


/* Test refine locational base */
void refine_location_test(FttCell * rootcell, int num){
	clock_t begin = clock();
	gpointer ptr2 = NULL; 
	gpointer angle = GINT_TO_POINTER (num);
	FttCellRefineFunc refine;
	refine = refineLocationFunc;
	FttCellInitFunc init;
	init = addFunc;
	ftt_cell_refine (rootcell, refine, angle, init, ptr2);
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	if(DEBUG) printf("Time for refine locational-base [NORMAL]:%lf seconds \n", time_spent);
}




/* Test refine locational base */
void pm_refine_location_test(FttCell * rootcell, FttCell * pmrootcell, guint i){

	clock_t begin = clock();
	dramcount = 0;	
	gpointer ptr2 = NULL; 
	gpointer angle = GINT_TO_POINTER (i);
	FttCellRefineFunc refine;
	refine = refineLocationFunc;
	FttCellInitFunc init;
	init = addFunc;
	ftt_cell_refine_pm (rootcell, refine, angle, init, ptr2, pmrootcell, 1, pmrootcell );	

	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	if(DEBUG) printf("Time for refine locational-based [NVRAM]: %lf seconds \n", time_spent);
		
}

/* Test refine locational base hyperboloid */
void pm_refine_location_test1(FttCell * rootcell, FttCell * pmrootcell){
	clock_t begin = clock();	
	gpointer ptr2 = NULL; 
	gpointer angle = GINT_TO_POINTER (0);
	FttCellRefineFunc refine;
	refine = refineLocationFunc1;
	FttCellInitFunc init;
	init = addFunc;
	ftt_cell_refine_pm (rootcell, refine, angle, init, ptr2, pmrootcell, 1, pmrootcell);
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	if(DEBUG) printf("Time for refine locational-based [NVRAM]: %lf seconds \n", time_spent);
}


/* Test refine locational base  hyperboloid*/
void refine_location_test1(FttCell * rootcell){
	clock_t begin = clock();	
	gpointer ptr2 = NULL; 
	gpointer angle = GINT_TO_POINTER (0);
	FttCellRefineFunc refine;
	refine = refineLocationFunc1;
	FttCellInitFunc init;
	init = addFunc;
	ftt_cell_refine (rootcell, refine, angle, init, ptr2);
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	if(DEBUG) printf("Time for refine locational-based [NORMAL]: %lf seconds \n", time_spent);
}


/* Test refine locational base */
void pm_refine_value_test(FttCell * rootcell, FttCell * pmrootcell){
	clock_t begin = clock();
	dramcount = 0;
	char c = 'B';
	int v = c;	
	gpointer ptr2 = NULL; 
	gpointer value = GINT_TO_POINTER (v);
	FttCellRefineFunc refine;
	refine = refineValueFunc;
	FttCellInitFunc init;
	init = addFunc;
	ftt_cell_refine_value_pm (rootcell, refine, value, init, ptr2, pmrootcell, 1, pmrootcell );
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	if(DEBUG) printf("Time for refine value-base[NVRAM]: %lf seconds \n", time_spent);
}

/* Test refine locational base */
void refine_value_test(FttCell * rootcell){
	clock_t begin = clock();
	char c = 'B';
	int v = c;	
	gpointer ptr2 = NULL; 
	gpointer value = GINT_TO_POINTER (v);
	FttCellRefineFunc refine;
	refine = refineValueFunc;
	FttCellInitFunc init;
	init = addFunc;
	ftt_cell_refine_value (rootcell, refine, value, init, ptr2);
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	if(DEBUG) printf("Time for refine value-base[NORMAL]: %lf seconds \n", time_spent);
}

/* Test refine level base */
void refine_level_test(FttCell * rootcell){
	clock_t begin = clock();
	gpointer ptr = NULL; 
	gpointer level = GINT_TO_POINTER (8);
	FttCellRefineFunc refine;
	refine = refineFunc;
	FttCellInitFunc init;
	init = addFunc;
	ftt_cell_refine (rootcell, refine, level, init, ptr);
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	if(DEBUG) printf("Time for refine level base[NORMAL]: %lf seconds \n", time_spent);
}

/* Test traverse function */
void traverse_test(FttCell * cell){
	FttCellTraverseFunc traverse;
	traverse = traverseFunc;
	gpointer ptr = GINT_TO_POINTER (10);
	ftt_cell_traverse(cell, FTT_POST_ORDER, FTT_TRAVERSE_ALL, 3, traverse, ptr);
}

/* Test pm_octree insert */
void pm_insert_test(char ** argv, FttCell * rootcell, FttCell * pmrootcell){
	FILE * fd;
	char line [MAX_BUFFER];
	int count = 0;
	address_t addr;
	FttCellInitFunc init;
	init = addFunc;
	//read part 2 and insert into V1 
	fd = fopen(argv[1], "r");
	while (fgets ( line, sizeof line, fd) != NULL ){		
		 sscanf(line, "%lf %lf %lf %d %d %d %c", &addr.x, &addr.y, &addr.z, &addr.level,  &addr.type, &addr.val, &addr.tag);	
        if ((line[0] == '#') || (line[0] == '\n') || (line[0] == '\t')) {
            continue;
        }
		count++;
		if(pm_octree){
			ftt_cell_insert_pm(pmrootcell, init, &addr, pmrootcell, TRUE, 0);
		}else{
			ftt_cell_insert_pm(rootcell, init, &addr, pmrootcell, TRUE, 1);
			pm_octree = 1;
		}
    }  
	fclose ( fd );
}

//return how deep we go to partition tree
int partition_deep(int size){
	int d = 0;
	int branch = 1;
	while(1){
		if(size < branch){
			 break;
		}else{
			branch *= 8;
			d++;
		}

	}
	return d;
}

//return number of branches on certain deep level
int total_branches(int deep){
	int i;
	int result = 1;
	for(i = 0; i < deep; i++){
		result *= 8;

	}
	return result;
}



/* Main function */
int main (int argc, char ** argv){	
	//MPI stuffs
#ifdef MPI
	//MPI_Status status;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
#endif

	gboolean checkneighbor = FALSE;
	if(argc < 2){
		printf("Usage: ./octree <filename> \n");
		exit(1);
	}else if (argc == 2){
	 	checkneighbor = TRUE;
	}else{
		checkneighbor = FALSE;
	}	
//read input file 
	FILE * fd;
	char line [MAX_BUFFER];
	fd = fopen(argv[1], "r");
	if(fd == NULL){
	 	fprintf(stderr, "Could not open file %s\n", argv[1]); 
        exit(1);
    }

//Simple test case to test functions
	int count1;
	count1 = 0;
	FttCell * rootcell;
    rootcell = g_malloc0 (sizeof (FttRootCell));
#ifdef NVRAM
	FttCell * pmrootcell;
    pmrootcell = g_malloc0 (sizeof (FttRootCell));
#endif
	address_t addr;
	FttCellInitFunc init;
	init = addFunc;
	double  begin = MPI_Wtime();	
	while (fgets ( line, sizeof line, fd) != NULL ){		
		 sscanf(line, "%lf %lf %lf %d %d %d %c", &addr.x, &addr.y, &addr.z, &addr.level,  &addr.type, &addr.val, &addr.tag);	
        /* Ignore comment or blank lines */
        if ((line[0] == '#') || (line[0] == '\n') || (line[0] == '\t')) {
            continue;
        }

	count1++;
#ifdef NVRAM
	ftt_cell_insert_pm(rootcell, init, &addr, pmrootcell, checkneighbor, 1);
#else
	checkneighbor = FALSE;
	ftt_cell_insert(rootcell, init, &addr, checkneighbor);
#endif

	//printf("Load x-y-z-level-type-val-tag %lf, %lf, %lf, %d, %d, %d, %c\n", addr.x, addr.y, addr.z, addr.level, addr.type, addr.val, addr.tag);
	}  
	if(DEBUG) printf("Load %d octants \n", count1);
		double  end = MPI_Wtime(); 
		double time_spent = (double)(end - begin);
	if(DEBUG) printf("Time for insert tree: %lf seconds \n", time_spent);	
	fclose ( fd );
	//pm_refine_test(rootcell, pmrootcell);

#ifdef MPI
	//determine how deep of partitioning tree
	deep = partition_deep(size);
	//determine how many branches on that deep level
	branches_on_deep = total_branches(deep);
	//branch each processor take care
	branch_each_processor = branches_on_deep/(size);
	//branch for last processor 
	branch_last_processor = branches_on_deep - ((size - 1)* branch_each_processor);
	//Using broad-cast instead of loop sending
	MPI_Bcast(&deep, 1 , MPI_INT , 0 , MPI_COMM_WORLD);
#endif

#ifdef LOCATION
	#ifdef NVRAM
			pm_persistent(&rootcell, &pmrootcell);
			double begin2 = MPI_Wtime();	
			pm_partition(rootcell, 7);
			double end2 = MPI_Wtime(); 
			double time_spent2 = (double)(end2 - begin2);
			if(DEBUG) printf("Time for partition to DRAM: %lf seconds \n", time_spent2);	
			pm_refine_location_test(rootcell, pmrootcell, 90);
			coarsen_test(pmrootcell);

			while(1){
				double  begin1 = MPI_Wtime();	
				pm_balance_tree(pmrootcell);
				if(balance){ 
					double  end1 = MPI_Wtime(); 
					double time_spent1 = (double)(end1 - begin1);
					if(DEBUG) printf("Time for balance: %lf seconds \n", time_spent1);	
					break;
				}
			}
			if(DEBUG) printf("Merge DRAM Octant to NVRAM %d times \n", num);
			pm_persistent(&rootcell, &pmrootcell);
			garbage_collector(pmrootcell);
	#else
			refine_location_test(rootcell, 90);
			coarsen_test(rootcell);
	#endif
#endif	



#ifdef HYPERBOLOID
	#ifdef NVRAM
			pm_persistent(&rootcell, &pmrootcell);
			double  begin1 = MPI_Wtime();	
			pm_partition(rootcell, 7);
			double  end1 = MPI_Wtime(); 
			double time_spent1 = (double)(end1 - begin1);	
			if(DEBUG) printf("Time for partition to DRAM: %lf seconds \n", time_spent1);	
			pm_refine_location_test1(rootcell, pmrootcell);
			coarsen_test(pmrootcell);

			while(1){
				clock_t begin = clock();	
				pm_balance_tree(pmrootcell);
				if(balance){ 
					clock_t end = clock();
					double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
					if(DEBUG) printf("Time for balance: %lf seconds \n", time_spent);	
					break;
				}
			}
			pm_persistent(&rootcell, &pmrootcell);
			garbage_collector(pmrootcell);
	#else
			refine_location_test1(rootcell);
			coarsen_test(rootcell);
	#endif
#endif	



#ifdef VALUE
	#ifdef NVRAM
			pm_persistent(&rootcell, &pmrootcell);
			double  begin1 = MPI_Wtime();	
			pm_partition(rootcell, 7);
			double  end1 = MPI_Wtime(); 
		double time_spent1 = (double)(end1 - begin1);
			if(DEBUG) printf("Value-Time for partition to DRAM: %lf seconds \n", time_spentt);	
			pm_refine_value_test(rootcell, pmrootcell);
			coarsen_test(pmrootcell);

			while(1){
				double  begin = MPI_Wtime();	
				pm_balance_tree(pmrootcell);
				if(balance){ 
					double  end = MPI_Wtime(); 
					double time_spent = (double)(end - begin);
					if(DEBUG) printf("Value-Time for balance: %lf seconds \n", time_spent);	
					break;
				}
			}

			pm_persistent(&rootcell, &pmrootcell);
			garbage_collector(pmrootcell);
			if(DEBUG) printf("Merge DRAM Octant to NVRAM %d times \n", num);
	#else
	
			refine_value_test(rootcell);
			coarsen_test(rootcell);
	#endif
#endif	


//if rotate many times
#ifdef MULTI
	#ifdef NVRAM
	guint n;
	for(n = 0; n < FTT_CELLS + 4; n++){
		pm_partition(rootcell, 7);
		pm_refine_location_test(rootcell, pmrootcell, n*30);
		pm_persistent(&rootcell, &pmrootcell);
		garbage_collector(pmrootcell);
	}
	#endif
#endif

//If extract mesh for visualization
#ifdef EXTRACTMESH
	#ifdef NVRAM
		double  begin1 = MPI_Wtime();	
		tree2file(rootcell);
		double  end1 = MPI_Wtime(); 
		double time_spent1 = (double)(end1 - begin1);
		if(DEBUG) printf("Time for extract mesh: %lf seconds \n", time_spent1);	
	#else
		double  begin1 = MPI_Wtime();	
		tree2file(rootcell);
		double  end1 = MPI_Wtime(); 
		double time_spent1 = (double)(end1 - begin1);
		if(DEBUG) printf("Time for extract mesh: %lf seconds \n", time_spent1);	
	#endif
#endif
	

//print the tree
	//print_test(pmrootcell, NULL);
//Insert test   
	//pm_insert_test(argv, rootcell, pmrootcell);
//Traverse test
	//traverse_test(rootcell);
//Refine test
	//refine_level_test(rootcell);
//Refine locatinal based test
	//refine_location_test(rootcell, 0);
	//refine_location_test(rootcell, 19);
	//refine_location_test(rootcell, 38);
//Coarsen test 
	//coarsen_test(rootcell);
//Refine pm_octree level based test 
	//pm_refine_test(rootcell, pmrootcell);
//Refine locatinal based  pm_octree_test	
/*
	pm_refine_location_test(rootcell, pmrootcell, 30);
	pm_persistent(&rootcell, &pmrootcell);
	pm_partition(rootcell, 7);
	pm_refine_location_test(rootcell, pmrootcell, 60);	
	print_test(rootcell, NULL);
*/
//Refine locatinal based  pm_octree_test1 - refine to create a hyperboloid
	//pm_refine_location_test1(rootcell, pmrootcell);

//Refine value based test
	//pm_refine_value_test(rootcell, pmrootcell);

//tree2file(rootcell);
//print_test(rootcell, NULL);
//print_test(NULL, pmrootcell);
#ifdef MPI
	MPI_Finalize();
#endif
    return 0;
}	
